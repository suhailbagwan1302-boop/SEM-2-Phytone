'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Activity, BarChart3, Bot, ClipboardCheck, Database, Factory, FileText, Gauge, Layers3, LockKeyhole, Radar, SearchCheck, Settings, ShieldCheck, ShieldAlert, Wrench } from 'lucide-react';

const groups = [
  { label: 'Command', items: [{ label: 'Overview', href: '/', icon: Gauge }, { label: 'AI Workbench', href: '/workbench', icon: Bot }] },
  { label: 'Knowledge', items: [{ label: 'Documents', href: '/documents', icon: FileText }, { label: 'Knowledge Base', href: '/knowledge-base', icon: Database }, { label: 'Data Analysis', href: '/data-analysis', icon: BarChart3 }] },
  { label: 'Operations', items: [{ label: 'Factory', href: '/factory', icon: Factory }, { label: 'Inspection', href: '/inspection', icon: ClipboardCheck }, { label: 'Maintenance', href: '/maintenance', icon: Wrench }, { label: 'Investigation', href: '/investigation', icon: SearchCheck }] },
  { label: 'AI Platform', items: [{ label: 'Agents', href: '/agents', icon: Layers3 }, { label: 'Models', href: '/models', icon: Radar }] },
  { label: 'Governance', items: [{ label: 'Security', href: '/security', icon: LockKeyhole }, { label: 'Audit Logs', href: '/audit-logs', icon: ShieldAlert }] },
];

export default function Sidebar() {
  const pathname = usePathname();
  return <aside className="app-sidebar"><div className="sidebar-scroll">
      {groups.map(group => <section className="nav-group" key={group.label}><div className="nav-label">{group.label}</div>
        {group.items.map(item => { const Icon = item.icon; const active = pathname === item.href || (item.href !== '/' && pathname.startsWith(item.href)); return <Link key={item.href} href={item.href} className={`nav-item ${active ? 'is-active' : ''}`}><Icon size={16}/><span>{item.label}</span>{active && <i />}</Link>; })}
      </section>)}
    </div><div className="sidebar-bottom"><button className="system-status" onClick={() => window.dispatchEvent(new Event('open-system-health'))}><span className="status-dot ok"/>SYSTEM OPERATIONAL</button><Link href="/settings" className="nav-item"><Settings size={16}/><span>Settings</span></Link><Link href="/sovereignty" className="nav-item"><ShieldCheck size={16}/><span>Sovereignty</span></Link><div className="sidebar-foot"><Activity size={12}/> AIR-GAPPED / LOCAL</div></div></aside>;
}
