'use client';

import React from 'react';
import { Cpu, CheckCircle2, AlertCircle, HardDrive, Zap, Layers, RefreshCw } from 'lucide-react';

export default function ModelManagerPage() {
  const models = [
    {
      name: 'Qwen2.5 14B Instruct',
      type: 'Text LLM / Reasoning',
      size: '9.0 GB',
      quantization: 'Q4_K_M',
      contextLength: '8,192 Tokens',
      location: 'Local Ollama Engine (/models)',
      status: 'CONNECTED',
      badgeColor: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
      description: 'Primary open-weight reasoning model for industrial multi-agent tool calling and report synthesis.'
    },
    {
      name: 'LLaVA 1.6 13B Vision',
      type: 'Multimodal VLM (Vision-Language)',
      size: '8.2 GB',
      quantization: 'Q4_0',
      contextLength: '4,096 Tokens',
      location: 'Local Ollama Engine (/models)',
      status: 'CONNECTED',
      badgeColor: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
      description: 'Open-weight visual vision model for defect flaw recognition and thermal image inspection.'
    },
    {
      name: 'BGE-M3 Dense Embedding Engine',
      type: 'Text Embedding',
      size: '2.2 GB',
      quantization: 'FP16',
      contextLength: '8,192 Tokens',
      location: 'Local PyTorch / ChromaDB',
      status: 'CONNECTED',
      badgeColor: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
      description: '1024-dimensional dense vector embedding model powering citation-based RAG search.'
    },
    {
      name: 'Llama 3.2 11B Vision Instruct',
      type: 'Multimodal LLM',
      size: '7.8 GB',
      quantization: 'Q4_K_S',
      contextLength: '8,192 Tokens',
      location: 'Available in local registry',
      status: 'AVAILABLE',
      badgeColor: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      description: 'Secondary open-weight multimodal model available for local switch.'
    },
    {
      name: 'Mistral 7B Instruct v0.3',
      type: 'Text LLM',
      size: '4.1 GB',
      quantization: 'Q4_0',
      contextLength: '32,768 Tokens',
      location: 'Local repository cache',
      status: 'AVAILABLE',
      badgeColor: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      description: 'Fast lightweight text model for quick status summarization.'
    },
    {
      name: 'DeepSeek R1 14B Distill',
      type: 'Reasoning Engine',
      size: '9.2 GB',
      quantization: 'Q4_K_M',
      contextLength: '16,384 Tokens',
      location: 'Not pulled to local disk',
      status: 'NOT INSTALLED',
      badgeColor: 'bg-slate-800 text-slate-400 border-slate-700',
      description: 'Deep reasoning model for complex root-cause incident investigation.'
    },
    {
      name: 'Gemma 2 27B Enterprise',
      type: 'Heavy LLM',
      size: '16.4 GB',
      quantization: 'Q4_K_M',
      contextLength: '8,192 Tokens',
      location: 'Demo Instance Preset',
      status: 'DEMO INSTANCE',
      badgeColor: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
      description: 'High-parameter model preset for high-GPU benchmark testing.'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl bg-slate-950 border border-slate-800 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs tracking-wider uppercase">
            <Cpu className="w-4 h-4" />
            <span>Open-Weight Model Infrastructure</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">On-Premise Model Management</h2>
          <p className="text-xs text-slate-400 max-w-2xl">
            Inventory of local open-weight LLMs, vision-language models, and dense vector embedding engines running on local GPU hardware.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold">
            3 MODELS CONNECTED & READY
          </span>
        </div>
      </div>

      {/* Model Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {models.map((m, idx) => (
          <div key={idx} className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4 shadow-md flex flex-col justify-between">
            <div className="space-y-2">
              <div className="flex items-start justify-between gap-2">
                <div className="space-y-0.5">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{m.type}</div>
                  <h3 className="text-base font-bold text-white">{m.name}</h3>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded border shrink-0 ${m.badgeColor}`}>
                  {m.status}
                </span>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">{m.description}</p>
            </div>

            <div className="space-y-2.5 pt-3 border-t border-slate-800/80 text-xs">
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-slate-500">Size / VRAM:</span>
                  <div className="font-bold text-slate-200">{m.size}</div>
                </div>
                <div>
                  <span className="text-slate-500">Quantization:</span>
                  <div className="font-bold text-slate-200">{m.quantization}</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-slate-500">Context Window:</span>
                  <div className="font-bold text-cyan-400">{m.contextLength}</div>
                </div>
                <div>
                  <span className="text-slate-500">Storage Location:</span>
                  <div className="font-bold text-slate-300 truncate">{m.location}</div>
                </div>
              </div>

              <div className="pt-2">
                {m.status === 'CONNECTED' ? (
                  <div className="w-full py-2 text-center text-xs font-bold rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    ✓ Active Default Model
                  </div>
                ) : m.status === 'AVAILABLE' ? (
                  <button className="w-full py-2 text-center text-xs font-bold rounded-xl bg-slate-900 hover:bg-slate-800 text-cyan-400 border border-slate-800 transition">
                    Switch Active Model
                  </button>
                ) : (
                  <div className="w-full py-2 text-center text-xs font-semibold rounded-xl bg-slate-900 text-slate-500 border border-slate-800">
                    {m.status}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
