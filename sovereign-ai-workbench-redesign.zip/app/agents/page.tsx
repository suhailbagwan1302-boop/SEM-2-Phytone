'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import {
  Layers,
  Bot,
  Wrench,
  Eye,
  FileText,
  Search,
  BarChart2,
  CheckCircle2,
  Play,
  ArrowRight,
  ShieldCheck,
  Cpu,
  Database,
  Lock,
  Sparkles
} from 'lucide-react';

const AGENTS = [
  {
    id: 'ag-1',
    name: 'Maintenance Assistant Agent',
    type: 'Multimodal Maintenance',
    icon: Wrench,
    purpose: 'Unified multimodal reasoning combining thermal imagery, sensor CSVs, manual specs, and service history.',
    tools: ['inspect_image', 'analyze_csv', 'search_knowledge_base', 'search_maintenance_history'],
    knowledgeSources: ['ChromaDB Vector Store', 'Sensor CSV Telemetry', 'Work Order DB'],
    permissions: 'ENGINEER, ADMIN',
    status: 'ACTIVE',
    model: 'Qwen2.5 14B + LLaVA 13B'
  },
  {
    id: 'ag-2',
    name: 'Document Analyst Agent',
    type: 'PDF & Manual Extraction',
    icon: FileText,
    purpose: 'Deep PDF/DOCX parsing, spec table extraction, document comparisons, and technical manual indexing.',
    tools: ['parse_pdf_pages', 'extract_spec_tables', 'compare_manuals'],
    knowledgeSources: ['Technical Manuals PDF Archive', 'SOP Guidelines'],
    permissions: 'ENGINEER, INSPECTOR, ADMIN',
    status: 'ACTIVE',
    model: 'Qwen2.5 14B'
  },
  {
    id: 'ag-3',
    name: 'Inspection Analyst Agent',
    type: 'Computer Vision Flaw Detection',
    icon: Eye,
    purpose: 'Visual flaw recognition, thermal anomaly hotspot mapping, surface pitting scoring, and component ID.',
    tools: ['inspect_image', 'detect_flaws', 'compute_thermal_hotspots'],
    knowledgeSources: ['Industrial Inspection Imagery', 'Flaw Taxonomy DB'],
    permissions: 'INSPECTOR, ENGINEER',
    status: 'ACTIVE',
    model: 'LLaVA 13B Vision Model'
  },
  {
    id: 'ag-4',
    name: 'Compliance Analyst Agent',
    type: 'Regulatory & EHS Audit',
    icon: ShieldCheck,
    purpose: 'Checks factory operations against EHS safety regulations and environmental compliance standards.',
    tools: ['verify_compliance_rules', 'audit_policy_gates', 'check_rbacs'],
    knowledgeSources: ['EHS Regulation Manuals', 'Factory Safety SOPs'],
    permissions: 'ADMIN, AUDITOR',
    status: 'ACTIVE',
    model: 'Qwen2.5 14B'
  },
  {
    id: 'ag-5',
    name: 'Engineering Assistant Agent',
    type: 'Telemetry & Signal Processing',
    icon: BarChart2,
    purpose: 'Statistical analysis of sensor telemetry CSVs, time-series anomaly detection, and vibration FFT analysis.',
    tools: ['analyze_csv', 'compute_fft_vibration', 'detect_sensor_spikes'],
    knowledgeSources: ['Live Telemetry Signals', 'CSV Archives'],
    permissions: 'ENGINEER, ADMIN',
    status: 'ACTIVE',
    model: 'Qwen2.5 14B'
  },
  {
    id: 'ag-6',
    name: 'Research Agent',
    type: 'Strict RAG Ground-Truth Search',
    icon: Search,
    purpose: 'Strict citation-based vector retrieval with Retrieval Guard evidence verification.',
    tools: ['search_knowledge_base', 'evaluate_retrieval_guard'],
    knowledgeSources: ['ChromaDB Dense Embeddings'],
    permissions: 'ALL ROLES',
    status: 'ACTIVE',
    model: 'BGE-M3 + Qwen2.5'
  },
  {
    id: 'ag-7',
    name: 'Report Generator Agent',
    type: 'Automated Technical Reporting',
    icon: Bot,
    purpose: 'Synthesizes multi-agent outputs into audit-ready executive engineering reports.',
    tools: ['compile_markdown_report', 'export_pdf_summary'],
    knowledgeSources: ['Multi-Agent Session Logs'],
    permissions: 'ENGINEER, ADMIN',
    status: 'ACTIVE',
    model: 'Qwen2.5 14B'
  }
];

const workflowSteps = [
  { step: 1, name: 'START', desc: 'Query intake' },
  { step: 2, name: 'UNDERSTAND TASK', desc: 'Decompose prompt intent' },
  { step: 3, name: 'RETRIEVE DATA', desc: 'RAG vector & sensor lookup' },
  { step: 4, name: 'ANALYZE', desc: 'Multimodal signal processing' },
  { step: 5, name: 'USE TOOL', desc: 'Execute domain tools' },
  { step: 6, name: 'VALIDATE', desc: 'Retrieval Guard verification' },
  { step: 7, name: 'GENERATE RESULT', desc: 'Citation-grounded output' }
];

export default function AgentsPage() {
  const [selectedAgent, setSelectedAgent] = useState(AGENTS[0]);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl bg-slate-950 border border-slate-800 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs tracking-wider uppercase">
            <Layers className="w-4 h-4" />
            <span>Agentic AI Orchestration Engine</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Agent Workspace & Workflow Monitor</h2>
          <p className="text-xs text-slate-400 max-w-2xl">
            Autonomous multi-agent state machines executing industrial tools, vector RAG searches, vision inspections, and telemetry signal analysis.
          </p>
        </div>

        <Link
          href="/workbench"
          className="px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md flex items-center gap-2 transition"
        >
          <Bot className="w-4 h-4" />
          <span>Execute Agent in Workbench</span>
        </Link>
      </div>

      {/* Visual Workflow Execution Timeline Graph */}
      <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>Agentic Execution Pipeline (7-Step Workflow Graph)</span>
          </h3>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            LANGGRAPH / REASONING ENGINE ACTIVE
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
          {workflowSteps.map((wf) => (
            <div key={wf.step} className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-center space-y-1">
              <div className="text-[10px] font-bold text-slate-500">STEP {wf.step}</div>
              <div className="text-xs font-bold text-cyan-400">{wf.name}</div>
              <div className="text-[10px] text-slate-400 leading-tight">{wf.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Agent Workspace Directory Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Agent Cards Directory */}
        <div className="lg:col-span-5 space-y-3">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
            Active Specialized Agents ({AGENTS.length})
          </div>

          <div className="space-y-2.5">
            {AGENTS.map((ag) => {
              const Icon = ag.icon;
              const isSelected = selectedAgent.id === ag.id;

              return (
                <button
                  key={ag.id}
                  onClick={() => setSelectedAgent(ag)}
                  className={`w-full text-left p-4 rounded-xl border transition-all flex items-start gap-3 ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-500/50 shadow-md shadow-cyan-500/10'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div
                    className={`p-2.5 rounded-xl shrink-0 ${
                      isSelected ? 'bg-cyan-500/20 text-cyan-400' : 'bg-slate-900 text-slate-400'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="space-y-1 min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <div className={`text-xs font-bold truncate ${isSelected ? 'text-cyan-400' : 'text-slate-200'}`}>
                        {ag.name}
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30 shrink-0">
                        {ag.status}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 line-clamp-1">{ag.purpose}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Agent Detailed Specs Inspector */}
        <div className="lg:col-span-7">
          <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-6 shadow-xl sticky top-20">
            {/* Header */}
            <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-4">
              <div className="space-y-1">
                <div className="text-xs font-bold text-cyan-400 uppercase tracking-wider">{selectedAgent.type}</div>
                <h3 className="text-xl font-bold text-white">{selectedAgent.name}</h3>
              </div>
              <div className="p-3 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                <selectedAgent.icon className="w-6 h-6" />
              </div>
            </div>

            {/* Purpose */}
            <div className="space-y-1.5">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Agent Purpose & Scope</div>
              <p className="text-xs text-slate-300 bg-slate-900 p-3.5 rounded-xl border border-slate-800 leading-relaxed">
                {selectedAgent.purpose}
              </p>
            </div>

            {/* Under-the-Hood Specs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <div className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider">Assigned LLM Model</div>
                <div className="font-bold text-white">{selectedAgent.model}</div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <div className="text-[11px] font-bold text-purple-400 uppercase tracking-wider">Required RBAC Permission</div>
                <div className="font-bold text-white">{selectedAgent.permissions}</div>
              </div>
            </div>

            {/* Executable Tools */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Executable Domain Tools ({selectedAgent.tools.length})</div>
              <div className="flex flex-wrap gap-2">
                {selectedAgent.tools.map((t, idx) => (
                  <span
                    key={idx}
                    className="text-xs font-mono bg-slate-900 text-cyan-300 border border-slate-800 px-3 py-1.5 rounded-xl flex items-center gap-1.5"
                  >
                    <Wrench className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{t}</span>
                  </span>
                ))}
              </div>
            </div>

            {/* Knowledge Sources */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Target Knowledge Sources</div>
              <div className="flex flex-wrap gap-2">
                {selectedAgent.knowledgeSources.map((ks, idx) => (
                  <span
                    key={idx}
                    className="text-xs bg-slate-900 text-slate-300 border border-slate-800 px-3 py-1.5 rounded-xl flex items-center gap-1.5"
                  >
                    <Database className="w-3.5 h-3.5 text-blue-400" />
                    <span>{ks}</span>
                  </span>
                ))}
              </div>
            </div>

            {/* Action */}
            <div className="pt-2">
              <Link
                href="/workbench"
                className="w-full py-3 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md flex items-center justify-center gap-2 transition"
              >
                <span>Launch {selectedAgent.name} in AI Workbench</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
