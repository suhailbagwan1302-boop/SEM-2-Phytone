'use client';

import React, { useState } from 'react';
import {
  BarChart2,
  Activity,
  Upload,
  AlertTriangle,
  FileSpreadsheet,
  TrendingUp,
  CheckCircle2
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

const TELEMETRY_DATA = Array.from({ length: 25 }, (_, i) => ({
  time: `14:${i < 10 ? '0' + i : i}`,
  temperature: Number((75.0 + i * 0.7 + (i > 15 ? 8.5 : 0)).toFixed(1)),
  vibration: Number((3.1 + i * 0.18 + (i > 15 ? 2.8 : 0)).toFixed(2)),
  pressure: Number((110.0 + (i % 5) * 1.5).toFixed(1))
}));

export default function DataAnalysisPage() {
  const [data, setData] = useState(TELEMETRY_DATA);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-emerald-950/40 border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center gap-2 text-emerald-400 font-semibold text-xs tracking-wider uppercase">
            <Activity className="w-4 h-4" />
            <span>Industrial Telemetry Signal Engine</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Sensor Telemetry & Time-Series Data Analysis</h2>
          <p className="text-xs text-slate-400">
            Pandas signal processing, statistical threshold checks, and interactive trend visualization for MACHINE-001.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 flex items-center gap-2 transition">
            <Upload className="w-4 h-4" />
            <span>Upload Sensor CSV</span>
          </button>
        </div>
      </div>

      {/* Recharts Time Series Telemetry Plot */}
      <div className="glass-panel p-5 rounded-2xl space-y-4 border-slate-800">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span>Real-Time Sensor Telemetry Signal Plot (MACHINE-001)</span>
            </h3>
            <p className="text-xs text-slate-400">Temperature (°C), Vibration (mm/s), and Pressure (PSI)</p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="px-2.5 py-1 rounded bg-rose-500/20 text-rose-400 font-bold border border-rose-500/30 flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Thermal Spike at 14:16 (94.5°C)</span>
            </span>
          </div>
        </div>

        <div className="h-80 w-full pt-4">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" />
              <XAxis dataKey="time" stroke="#9CA3AF" fontSize={11} />
              <YAxis stroke="#9CA3AF" fontSize={11} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0B0F17', borderColor: '#374151', borderRadius: '8px', fontSize: '12px' }}
              />
              <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
              <Line type="monotone" dataKey="temperature" name="Temperature (°C)" stroke="#EF4444" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="vibration" name="Vibration (mm/s)" stroke="#F59E0B" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="pressure" name="Pressure (PSI)" stroke="#06B6D4" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Statistical Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="glass-card p-4 rounded-xl space-y-2 border-rose-500/30">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Temperature Channel (temperature_c)</span>
            <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 font-bold text-[10px]">ANOMALY</span>
          </div>
          <div className="text-xl font-bold text-rose-400">Peak: 94.5°C</div>
          <div className="text-[11px] text-slate-400">Mean: 82.4°C | Threshold: 85.0°C (Exceeded)</div>
        </div>

        <div className="glass-card p-4 rounded-xl space-y-2 border-amber-500/30">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Vibration Channel (vibration_mms)</span>
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 font-bold text-[10px]">WARNING</span>
          </div>
          <div className="text-xl font-bold text-amber-400">Peak: 8.2 mm/s</div>
          <div className="text-[11px] text-slate-400">Mean: 4.8 mm/s | Threshold: 6.0 mm/s (Exceeded)</div>
        </div>

        <div className="glass-card p-4 rounded-xl space-y-2 border-emerald-500/30">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Pressure Channel (pressure_psi)</span>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold text-[10px]">NOMINAL</span>
          </div>
          <div className="text-xl font-bold text-emerald-400">Mean: 112.5 PSI</div>
          <div className="text-[11px] text-slate-400">Min: 110.0 | Max: 116.0 PSI (Within Limits)</div>
        </div>
      </div>
    </div>
  );
}
