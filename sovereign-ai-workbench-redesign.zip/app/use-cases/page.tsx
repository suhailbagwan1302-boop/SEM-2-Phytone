'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import {
  Briefcase,
  Wrench,
  Eye,
  FileText,
  SearchCheck,
  ShieldCheck,
  Bot,
  Layers,
  ArrowRight,
  CheckCircle2,
  Lock,
  Cpu
} from 'lucide-react';

const USE_CASES = [
  {
    id: 'uc-1',
    title: 'Predictive Maintenance Assistance',
    category: 'Predictive Maintenance',
    icon: Wrench,
    problem: 'Vibration and thermal sensor spikes frequently result in unplanned machinery outages if not synthesized with historical service logs.',
    workflow: 'Sensor CSV Analysis → Vector RAG Manual Lookup → Multi-Agent Risk Scoring → Actionable Maintenance Recommendation.',
    input: 'Sensor Telemetry CSV, Machinery Manual PDF, Historical Work Order DB',
    output: 'Structured Condition Assessment Report with risk level and recommended oil/bearing service timeline.',
    security: '100% On-Premise telemetry processing. Zero sensor data transmitted to external cloud APIs.'
  },
  {
    id: 'uc-2',
    title: 'Equipment Vision Flaw Inspection',
    category: 'Quality & Inspection',
    icon: Eye,
    problem: 'Manual visual inspections of turbine bearing races and gear teeth are time-consuming and prone to human oversight during shift rotations.',
    workflow: 'LLaVA Visual Feature Extraction → Surface Pitting Recognition → Thermal Hotspot Mapping → Defect Severity Rating.',
    input: 'High-Resolution Industrial Imagery, Infrared Thermography Photos',
    output: 'Defect severity score (WARNING/CRITICAL), component flaw bounding analysis, and replacement urgency.',
    security: 'Local vision model execution (LLaVA) on air-gapped GPU infrastructure.'
  },
  {
    id: 'uc-3',
    title: 'Technical Document & Manual Intelligence',
    category: 'Document Intelligence',
    icon: FileText,
    problem: 'Engineers spend hours searching through multi-hundred page PDF technical manuals during emergency breakdown situations.',
    workflow: 'OCR & Layout Parsing → 400-token Semantic Chunking → BGE-M3 Dense Vector Embeddings → Citation-Grounded Search.',
    input: 'OEM Equipment Manuals, Engineering Specifications, Piping Schematics',
    output: 'Instant citation-referenced answers with direct document page and section line references.',
    security: 'Department-level RBAC classification tags (CONFIDENTIAL, RESTRICTED, INTERNAL).'
  },
  {
    id: 'uc-4',
    title: 'Engineering Knowledge Base Search',
    category: 'Knowledge Search',
    icon: SearchCheck,
    problem: 'Cross-departmental engineering expertise is fragmented across legacy files and siloed operational directories.',
    workflow: 'Unified Multi-Directory Ingestion → Dense Vector Indexing → Retrieval Guard Verification → Summarized Synthesis.',
    input: 'Multi-Format Technical Archives (PDF, DOCX, TXT, CSV, Engineering Schematics)',
    output: 'Verified answers with confidence scores and source document evidence breakdown.',
    security: 'Retrieval Guard refuses ungrounded queries if knowledge base relevance is below threshold.'
  },
  {
    id: 'uc-5',
    title: 'Maintenance Report Comparison',
    category: 'Asset Management',
    icon: Layers,
    problem: 'Comparing current telemetry anomalies with historical service reports from previous years is tedious.',
    workflow: 'Dual Document Parsing → Comparative Feature Matrix → Trend Anomaly Extraction → Variance Highlights.',
    input: 'Historical Maintenance Logs (2023-2026), Current Telemetry CSV',
    output: 'Comparative delta analysis highlighting degradation trends and recurring component wear.',
    security: 'Cryptographically signed audit logs for every document comparison session.'
  },
  {
    id: 'uc-6',
    title: 'Root Cause Incident Investigation',
    category: 'Root Cause Analysis',
    icon: SearchCheck,
    problem: 'Investigating complex turbine trippings requires combining visual evidence, sensor readings, and operator logs into an audit-proof report.',
    workflow: 'Hypothesis Generation Agent → Multimodal Evidence Verification → Root Cause Tree Assembly → Executive Synthesis.',
    input: 'Trip Logs, Telemetry Files, Operator Shift Notes, Vibration Spectra',
    output: 'Root Cause Incident Analysis with probability ratings, evidence chain, and preventive steps.',
    security: 'Air-gapped execution logged to immutable on-premise SQLite audit log.'
  },
  {
    id: 'uc-7',
    title: 'Standard Operating Procedure (SOP) Guidance',
    category: 'Operational Safety',
    icon: ShieldCheck,
    problem: 'Operators need rapid step-by-step guidance on complex machinery startup/shutdown procedures under strict safety standards.',
    workflow: 'SOP Document Retrieval → Step Sequence Extraction → Safety Clearance Check → Interactive Protocol Display.',
    input: 'Plant SOP Manuals, EHS Safety Regulations',
    output: 'Checklist-style operational guidelines with safety warnings and mandatory lock-out/tag-out rules.',
    security: 'Enforced AI Policy Gates blocking unsafe or unverified operational procedure modifications.'
  },
  {
    id: 'uc-8',
    title: 'Compliance & Safety Document Analysis',
    category: 'Regulatory Compliance',
    icon: Lock,
    problem: 'Ensuring industrial operations align with updated environmental and workplace safety regulations requires constant audit.',
    workflow: 'Regulatory Document Indexing → Clause Compliance Matching → Non-Conformance Detector → Audit Readiness Summary.',
    input: 'EHS Regulations, Environmental Emission Limits, Factory Compliance Standards',
    output: 'Compliance gap analysis matrix detailing compliant parameters vs flagged risk areas.',
    security: 'Full auditability tracking policy checks, model inferences, and human sign-off status.'
  },
  {
    id: 'uc-9',
    title: 'Automated Technical Report Generation',
    category: 'Reporting & Analytics',
    icon: Bot,
    problem: 'Compiling weekly machinery health and maintenance summary reports takes valuable engineering hours.',
    workflow: 'Weekly Telemetry Aggregation → Incident Log Summarization → Report Generator Agent Synthesis → Markdown Export.',
    input: 'Weekly Fleet Telemetry, Maintenance Log DB, Inspection Records',
    output: 'Formatted executive summary report ready for plant management review.',
    security: 'Local report compilation with zero cloud upload.'
  }
];

export default function IndustrialUseCasesPage() {
  const [selectedCase, setSelectedCase] = useState(USE_CASES[0]);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl bg-slate-950 border border-slate-800 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs tracking-wider uppercase">
            <Briefcase className="w-4 h-4" />
            <span>Enterprise Solutions</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Industrial Multimodal AI Use Cases</h2>
          <p className="text-xs text-slate-400 max-w-2xl">
            Real-world enterprise applications built on confidential on-premise LLMs, multimodal vision agents, and citation-based RAG.
          </p>
        </div>

        <Link
          href="/workbench"
          className="px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md flex items-center gap-2 transition"
        >
          <Bot className="w-4 h-4" />
          <span>Launch AI Workbench</span>
        </Link>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Use Case Selectors */}
        <div className="lg:col-span-5 space-y-3">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
            Industrial Use Cases ({USE_CASES.length})
          </div>

          <div className="space-y-2">
            {USE_CASES.map((uc) => {
              const Icon = uc.icon;
              const isSelected = selectedCase.id === uc.id;

              return (
                <button
                  key={uc.id}
                  onClick={() => setSelectedCase(uc)}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-start gap-3 ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-500/50 shadow-md shadow-cyan-500/10'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div
                    className={`p-2 rounded-lg shrink-0 ${
                      isSelected ? 'bg-cyan-500/20 text-cyan-400' : 'bg-slate-900 text-slate-400'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="space-y-0.5 min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <div className={`text-xs font-bold truncate ${isSelected ? 'text-cyan-400' : 'text-slate-200'}`}>
                        {uc.title}
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800 shrink-0">
                        {uc.category}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 line-clamp-1">{uc.problem}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Detailed Use Case Specification */}
        <div className="lg:col-span-7">
          <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-6 shadow-xl sticky top-20">
            {/* Title & Badge */}
            <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-4">
              <div className="space-y-1">
                <div className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                  {selectedCase.category}
                </div>
                <h3 className="text-xl font-bold text-white">{selectedCase.title}</h3>
              </div>
              <div className="p-3 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                <selectedCase.icon className="w-6 h-6" />
              </div>
            </div>

            {/* Problem Statement */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-rose-400" />
                <span>Industrial Challenge / Problem Statement</span>
              </h4>
              <p className="text-xs text-slate-300 bg-slate-900 p-3.5 rounded-xl border border-slate-800 leading-relaxed">
                {selectedCase.problem}
              </p>
            </div>

            {/* AI Workflow Flowchart */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-cyan-400" />
                <span>Automated AI Workflow</span>
              </h4>
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-cyan-300 leading-relaxed">
                {selectedCase.workflow}
              </div>
            </div>

            {/* Input & Output Specs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
                <div className="text-[11px] font-bold text-blue-400 uppercase tracking-wider">Multimodal Input Data</div>
                <p className="text-xs text-slate-300 leading-relaxed">{selectedCase.input}</p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
                <div className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">AI Generated Output</div>
                <p className="text-xs text-slate-300 leading-relaxed">{selectedCase.output}</p>
              </div>
            </div>

            {/* Security & Confidentiality Safeguard */}
            <div className="p-4 rounded-xl bg-slate-900 border border-emerald-500/30 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                <ShieldCheck className="w-4 h-4" />
                <span>Sovereignty & Security Guarantee</span>
              </div>
              <p className="text-xs text-slate-300">{selectedCase.security}</p>
            </div>

            {/* Action Link */}
            <div className="pt-2">
              <Link
                href="/workbench"
                className="w-full py-3 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md flex items-center justify-center gap-2 transition"
              >
                <span>Execute {selectedCase.title} in Workbench</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
