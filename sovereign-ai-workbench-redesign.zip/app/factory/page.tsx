'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import {
  Factory,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Wrench,
  SearchCheck,
  ArrowUpRight,
  Sparkles
} from 'lucide-react';

const FACTORY_MACHINES = [
  { code: 'M01', name: 'Gas Turbine Generator Unit-1', status: 'WARNING', health: 82, temp: 94.5, vibration: 8.2, dept: 'Power Gen' },
  { code: 'M02', name: 'Boiler Feed Pump Unit-2', status: 'NORMAL', health: 96, temp: 72.1, vibration: 2.4, dept: 'Water Treatment' },
  { code: 'M03', name: 'Centrifugal Compressor Unit-3', status: 'CRITICAL', health: 58, temp: 98.2, vibration: 11.5, dept: 'Pneumatics' },
  { code: 'M04', name: 'CNC Precision Lathe Machine', status: 'NORMAL', health: 98, temp: 68.0, vibration: 1.2, dept: 'Machining' },
  { code: 'M05', name: 'Robotic Welding Cell A', status: 'NORMAL', health: 94, temp: 71.5, vibration: 1.8, dept: 'Assembly' },
  { code: 'M06', name: 'Hydraulic Press Unit-6', status: 'WARNING', health: 79, temp: 86.4, vibration: 6.8, dept: 'Stamping' },
  { code: 'M07', name: 'Induction Furnace Unit-7', status: 'NORMAL', health: 91, temp: 74.0, vibration: 2.0, dept: 'Foundry' },
  { code: 'M08', name: 'Cooling Tower Pump B', status: 'NORMAL', health: 97, temp: 65.2, vibration: 1.5, dept: 'Utilities' }
];

export default function DigitalFactoryPage() {
  const [selectedMachine, setSelectedMachine] = useState<any>(FACTORY_MACHINES[0]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950/40 border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs tracking-wider uppercase">
            <Factory className="w-4 h-4" />
            <span>Digital Twin Floor Grid</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Digital Factory & Industrial Asset Fleet Map</h2>
          <p className="text-xs text-slate-400">
            Real-time visual factory floor grid showing operational status indicators (Green = Healthy, Yellow = Warning, Red = Critical).
          </p>
        </div>
      </div>

      {/* Main Grid: Machine Map Left, Selected Machine Details Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Machine Cards Floor Grid */}
        <div className="lg:col-span-2 glass-panel p-5 rounded-2xl space-y-4 border-slate-800">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Factory Floor Plan (8 Monitored Assets)</h3>
            <div className="flex items-center gap-3 text-[10px] font-bold">
              <span className="flex items-center gap-1 text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400" /> Healthy (5)
              </span>
              <span className="flex items-center gap-1 text-amber-400">
                <span className="w-2 h-2 rounded-full bg-amber-400" /> Warning (2)
              </span>
              <span className="flex items-center gap-1 text-rose-400">
                <span className="w-2 h-2 rounded-full bg-rose-400" /> Critical (1)
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {FACTORY_MACHINES.map((m) => (
              <div
                key={m.code}
                onClick={() => setSelectedMachine(m)}
                className={`p-4 rounded-xl border transition cursor-pointer flex flex-col justify-between space-y-3 ${
                  selectedMachine.code === m.code
                    ? 'bg-slate-900 border-cyan-500 shadow-lg shadow-cyan-500/10'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-white font-mono">{m.code}</span>
                  <span
                    className={`w-3 h-3 rounded-full ${
                      m.status === 'CRITICAL'
                        ? 'bg-rose-500 animate-pulse pulse-rose'
                        : m.status === 'WARNING'
                        ? 'bg-amber-500 animate-pulse pulse-amber'
                        : 'bg-emerald-500 pulse-emerald'
                    }`}
                  />
                </div>

                <div className="space-y-1 text-xs">
                  <div className="text-slate-400 text-[11px] truncate">{m.dept}</div>
                  <div className="font-bold text-slate-200">{m.health}% Health</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Machine Drilldown Panel */}
        <div className="glass-panel p-5 rounded-2xl space-y-5 border-slate-800">
          {selectedMachine && (
            <>
              <div className="border-b border-slate-800 pb-3 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-cyan-400 uppercase font-mono">{selectedMachine.code}</span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                      selectedMachine.status === 'CRITICAL'
                        ? 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                        : selectedMachine.status === 'WARNING'
                        ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                        : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                    }`}
                  >
                    {selectedMachine.status}
                  </span>
                </div>
                <h3 className="text-base font-bold text-white">{selectedMachine.name}</h3>
              </div>

              <div className="space-y-3 text-xs">
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <div className="text-slate-400 text-[10px]">Health Score</div>
                    <div className="text-lg font-bold text-cyan-400">{selectedMachine.health}%</div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <div className="text-slate-400 text-[10px]">Temperature</div>
                    <div className="text-lg font-bold text-amber-400">{selectedMachine.temp}°C</div>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <div className="text-slate-400 text-[10px]">Vibration Telemetry</div>
                  <div className="text-sm font-bold text-slate-200">{selectedMachine.vibration} mm/s</div>
                </div>
              </div>

              <div className="pt-2">
                <Link
                  href="/investigation"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2 transition"
                >
                  <SearchCheck className="w-4 h-4" />
                  <span>Run AI Root Cause Investigation</span>
                </Link>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
