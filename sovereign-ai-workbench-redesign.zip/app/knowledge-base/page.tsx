'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import {
  FileText,
  Search,
  Upload,
  Database,
  CheckCircle2,
  Cpu,
  Layers,
  ArrowRight,
  Filter,
  RefreshCw,
  Eye,
  FileCode,
  Image as ImageIcon,
  Activity,
  Tag,
  ShieldCheck
} from 'lucide-react';

export default function KnowledgeBasePage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [selectedDoc, setSelectedDoc] = useState<any>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStep, setUploadStep] = useState(0);

  const [documents, setDocuments] = useState([
    {
      id: 'doc-001',
      filename: 'Gas_Turbine_MACHINE-001_Maintenance_Manual.pdf',
      type: 'PDF / Manual',
      category: 'Technical Manual',
      department: 'Power Generation',
      size: '2.4 MB',
      chunks: 38,
      embeddings: 'BGE-M3 (1024d)',
      classification: 'CONFIDENTIAL',
      status: 'INDEXED',
      uploadedAt: '2026-08-23 14:00',
      sampleQuery: 'What are the operational temperature limits for Gas Turbine MACHINE-001?'
    },
    {
      id: 'doc-002',
      filename: 'MACHINE-001_Sensor_Telemetry.csv',
      type: 'CSV / Telemetry',
      category: 'Sensor Signal Data',
      department: 'Pneumatics',
      size: '1.8 MB',
      chunks: 100,
      embeddings: 'Time-Series Vector',
      classification: 'INTERNAL',
      status: 'INDEXED',
      uploadedAt: '2026-08-23 14:15',
      sampleQuery: 'Identify vibration and temperature channel exceedances in sensor CSV.'
    },
    {
      id: 'doc-003',
      filename: 'turbine_bearing_inspection.jpg',
      type: 'Image / Inspection',
      category: 'Visual Inspection',
      department: 'Quality & Inspection',
      size: '4.2 MB',
      chunks: 1,
      embeddings: 'CLIP / LLaVA Embed',
      classification: 'RESTRICTED',
      status: 'INDEXED',
      uploadedAt: '2026-08-23 14:30',
      sampleQuery: 'Analyze surface flaw severity on turbine bearing outer race.'
    },
    {
      id: 'doc-004',
      filename: 'Centrifugal_Compressor_Diagram_Schematic.png',
      type: 'Technical Diagram',
      category: 'Engineering Drawings',
      department: 'Maintenance & Engineering',
      size: '5.6 MB',
      chunks: 12,
      embeddings: 'Multimodal Vector',
      classification: 'CONFIDENTIAL',
      status: 'INDEXED',
      uploadedAt: '2026-08-23 15:10',
      sampleQuery: 'Explain air intake centrifugal compressor flow valves and seals.'
    },
    {
      id: 'doc-005',
      filename: 'Boiler_Feed_Pump_TURBINE-002_SOP.docx',
      type: 'DOCX / SOP',
      category: 'Standard Operating Procedure',
      department: 'Water Treatment',
      size: '890 KB',
      chunks: 16,
      embeddings: 'BGE-M3 (1024d)',
      classification: 'INTERNAL',
      status: 'INDEXED',
      uploadedAt: '2026-08-22 10:20',
      sampleQuery: 'What is the startup sequence for high pressure feed pump TURBINE-002?'
    }
  ]);

  const pipelineSteps = [
    { step: 1, name: 'Upload', desc: 'Secure local storage ingest' },
    { step: 2, name: 'OCR / Parsing', desc: 'PyMuPDF & Tesseract vision' },
    { step: 3, name: 'Metadata Extraction', desc: 'Department & classification tagging' },
    { step: 4, name: 'Classification', desc: 'RBAC security assignment' },
    { step: 5, name: 'Chunking', desc: '400-token semantic windowing' },
    { step: 6, name: 'Embedding', desc: 'BGE-M3 1024d vectorization' },
    { step: 7, name: 'Vector Storage', desc: 'ChromaDB local persistence' },
    { step: 8, name: 'Ready for AI', desc: 'Available for RAG retrieval' }
  ];

  const handleSimulateUpload = async () => {
    setIsUploading(true);
    for (let s = 1; s <= 8; s++) {
      setUploadStep(s);
      await new Promise((r) => setTimeout(r, 350));
    }
    const newDoc = {
      id: `doc-${Date.now()}`,
      filename: 'Industrial_Safety_Protocol_2026.pdf',
      type: 'PDF / Document',
      category: 'Safety Standard',
      department: 'Safety & Environmental',
      size: '3.1 MB',
      chunks: 24,
      embeddings: 'BGE-M3 (1024d)',
      classification: 'CONFIDENTIAL',
      status: 'INDEXED',
      uploadedAt: 'Just Now',
      sampleQuery: 'What are the required PPE standards during emergency shutdown?'
    };
    setDocuments((prev) => [newDoc, ...prev]);
    setIsUploading(false);
    setUploadStep(0);
  };

  const filteredDocs = documents.filter((d) => {
    const matchesSearch = d.filename.toLowerCase().includes(searchTerm.toLowerCase()) || d.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = selectedCategory === 'ALL' || d.category.includes(selectedCategory);
    return matchesSearch && matchesCat;
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl bg-slate-950 border border-slate-800 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs tracking-wider uppercase">
            <Database className="w-4 h-4" />
            <span>Multimodal Knowledge Intelligence</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Industrial Knowledge Base Management</h2>
          <p className="text-xs text-slate-400 max-w-2xl">
            Unified ingestion and retrieval across PDFs, DOCX, CSVs, technical diagrams, inspection images, and scanned engineering drawings.
          </p>
        </div>

        <button
          onClick={handleSimulateUpload}
          disabled={isUploading}
          className="px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md flex items-center gap-2 transition disabled:opacity-50"
        >
          <Upload className="w-4 h-4" />
          <span>{isUploading ? `Ingesting (Step ${uploadStep}/8)...` : 'Upload Industrial Document'}</span>
        </button>
      </div>

      {/* Unified Ingestion Workflow Visual Pipeline Tracker */}
      <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            <span>Unified Industrial Ingestion Workflow (8-Stage Pipeline)</span>
          </h3>
          <span className="text-[11px] text-slate-400 font-mono">Status: 100% LOCAL PROCESSING</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
          {pipelineSteps.map((p) => (
            <div
              key={p.step}
              className={`p-3 rounded-xl border text-center space-y-1 transition-all ${
                isUploading && uploadStep === p.step
                  ? 'bg-cyan-500/20 border-cyan-500 text-cyan-400 shadow-md animate-pulse'
                  : 'bg-slate-900 border-slate-800 text-slate-300'
              }`}
            >
              <div className="text-[10px] font-bold text-slate-500">STAGE {p.step}</div>
              <div className="text-xs font-bold truncate">{p.name}</div>
              <div className="text-[10px] text-slate-500 leading-tight">{p.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Search & Filter Controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-xl bg-slate-950 border border-slate-800">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search documents, categories, or keywords..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-xs text-slate-400">Category:</span>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none"
          >
            <option value="ALL">All Categories</option>
            <option value="Technical Manual">Technical Manuals</option>
            <option value="Sensor Signal Data">Sensor Signals</option>
            <option value="Visual Inspection">Visual Inspections</option>
            <option value="Engineering Drawings">Engineering Schematics</option>
            <option value="Standard Operating Procedure">SOP Documents</option>
          </select>
        </div>
      </div>

      {/* Document Records Table */}
      <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white">Indexed Knowledge Base Inventory ({filteredDocs.length})</h3>
          <span className="text-xs text-slate-400">Air-gapped Vector Storage: ChromaDB</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300 border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider">
                <th className="py-3 px-4">Document Title</th>
                <th className="py-3 px-4">Data Type</th>
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4">Chunks</th>
                <th className="py-3 px-4">Security</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredDocs.map((doc) => (
                <tr key={doc.id} className="hover:bg-slate-900/50 transition">
                  <td className="py-3 px-4 font-semibold text-white">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span>{doc.filename}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-slate-400">{doc.type}</td>
                  <td className="py-3 px-4 text-slate-400">{doc.department}</td>
                  <td className="py-3 px-4 font-mono text-cyan-400">{doc.chunks} vectors</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-400 border border-purple-500/30">
                      {doc.classification}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 w-fit">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>{doc.status}</span>
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <Link
                      href="/workbench"
                      className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-400 text-[11px] font-semibold transition inline-block"
                    >
                      Query AI
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
