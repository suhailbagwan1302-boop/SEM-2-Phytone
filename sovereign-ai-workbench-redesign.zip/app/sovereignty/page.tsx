'use client';

import React from 'react';
import {
  ShieldCheck,
  Lock,
  Cpu,
  Server,
  Database,
  FileText,
  CheckCircle2,
  AlertTriangle,
  Activity,
  UserCheck,
  Award
} from 'lucide-react';

export default function SovereigntyPage() {
  const governanceItems = [
    {
      system: 'Multimodal AI Workbench',
      model: 'Qwen2.5 14B / LLaVA 13B',
      version: 'v2.5.1-local',
      riskLevel: 'LOW',
      dataSource: 'ChromaDB Local Vector Store',
      accessPermissions: 'ENGINEER, ADMIN, INSPECTOR',
      humanApproval: 'REQUIRED FOR MAINTENANCE ACTIONS',
      status: 'COMPLIANT'
    },
    {
      system: 'Predictive Maintenance Agent',
      model: 'Qwen2.5 14B + Tool Reasoning',
      version: 'v1.8.0-local',
      riskLevel: 'MEDIUM',
      dataSource: 'Sensor CSV & Maintenance Logs DB',
      accessPermissions: 'ENGINEER, ADMIN',
      humanApproval: 'REQUIRED BEFORE WORK ORDER ISSUANCE',
      status: 'COMPLIANT'
    },
    {
      system: 'Vision Inspection Flaw Detector',
      model: 'LLaVA 13B Vision Model',
      version: 'v1.4.2-local',
      riskLevel: 'LOW',
      dataSource: 'Industrial Image Storage (/storage)',
      accessPermissions: 'INSPECTOR, ENGINEER',
      humanApproval: 'AUTOMATED PRE-SCREENING',
      status: 'COMPLIANT'
    },
    {
      system: 'Security Firewall Guard',
      model: 'Regex & Embedding Policy Classifier',
      version: 'v3.0.1-local',
      riskLevel: 'CRITICAL (GUARD)',
      dataSource: 'RBAC Policy Rules Matrix',
      accessPermissions: 'SYSTEM ADMIN ONLY',
      humanApproval: 'ENFORCED AUTOMATED GATE',
      status: 'COMPLIANT'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl bg-slate-950 border border-slate-800 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-emerald-400 font-semibold text-xs tracking-wider uppercase">
            <ShieldCheck className="w-4 h-4" />
            <span>Enterprise AI Governance & Sovereignty</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">AI Governance & Data Sovereignty Dashboard</h2>
          <p className="text-xs text-slate-400 max-w-2xl">
            Audit-proof AI governance, risk level classification, human approval controls, and on-premise air-gapped network isolation.
          </p>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900 border border-emerald-500/30 flex items-center gap-3">
          <Award className="w-8 h-8 text-emerald-400 shrink-0" />
          <div>
            <div className="text-[10px] text-slate-400 uppercase font-bold">AI Governance Risk Score</div>
            <div className="text-lg font-bold text-emerald-400">98.4 / 100 (SECURE)</div>
          </div>
        </div>
      </div>

      {/* Deployment & Sovereignty Specs Card */}
      <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Server className="w-4 h-4 text-cyan-400" />
          <span>Air-Gapped Deployment Architecture & Specifications</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
            <div className="text-[10px] font-bold text-slate-400">INTERNET ACCESS</div>
            <div className="font-bold text-emerald-400">DISABLED (AIR-GAPPED)</div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
            <div className="text-[10px] font-bold text-slate-400">DATA PROCESSING</div>
            <div className="font-bold text-cyan-400">100% LOCAL ON-PREMISE</div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
            <div className="text-[10px] font-bold text-slate-400">LLM INFERENCE</div>
            <div className="font-bold text-purple-400">ON-PREMISE OPEN-WEIGHT</div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
            <div className="text-[10px] font-bold text-slate-400">VECTOR DATABASE</div>
            <div className="font-bold text-blue-400">CHROMADB LOCAL / EMBED</div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
            <div className="text-[10px] font-bold text-slate-400">STORAGE LOCATION</div>
            <div className="font-bold text-slate-200">LOCAL ENCRYPTED DISK</div>
          </div>
        </div>
      </div>

      {/* Governance Inventory Table */}
      <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white">AI Systems Governance Inventory</h3>
          <span className="text-xs text-slate-400">Human-in-the-Loop Controls Active</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300 border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider">
                <th className="py-3 px-4">AI System Name</th>
                <th className="py-3 px-4">Model & Version</th>
                <th className="py-3 px-4">Risk Level</th>
                <th className="py-3 px-4">Data Source</th>
                <th className="py-3 px-4">Human Approval</th>
                <th className="py-3 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {governanceItems.map((item, idx) => (
                <tr key={idx} className="hover:bg-slate-900/50 transition">
                  <td className="py-3 px-4 font-bold text-white">{item.system}</td>
                  <td className="py-3 px-4 text-slate-300">
                    <div>{item.model}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{item.version}</div>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                        item.riskLevel.includes('CRITICAL')
                          ? 'bg-purple-500/20 text-purple-400 border-purple-500/30'
                          : item.riskLevel === 'MEDIUM'
                          ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                      }`}
                    >
                      {item.riskLevel}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-400">{item.dataSource}</td>
                  <td className="py-3 px-4 text-slate-300 font-semibold">{item.humanApproval}</td>
                  <td className="py-3 px-4 text-right">
                    <span className="px-2.5 py-1 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      ✓ {item.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
