'use client';

import React, { useState } from 'react';
import {
  SearchCheck,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Activity,
  Eye,
  Wrench,
  ArrowDown,
  ShieldCheck
} from 'lucide-react';

export default function AIInvestigationPage() {
  const [isRunning, setIsRunning] = useState(false);

  const [timeline, setTimeline] = useState([
    { step: 1, stage: 'Problem Identified', description: 'Trigger: Abnormal vibration (8.2 mm/s) & thermal spike (94.5°C)', status: 'COMPLETED' },
    { step: 2, stage: 'Machine Identified', description: 'Target Asset: MACHINE-001 (Gas Turbine Generator Unit-1)', status: 'COMPLETED' },
    { step: 3, stage: 'Telemetry Collected', description: '100 sensor timestamp records ingested. Peak temp 94.5°C at t=14:16', status: 'COMPLETED' },
    { step: 4, stage: 'Documents Searched', description: 'RAG retrieved manual Section 1 & 3 (Max thermal limit 85.0°C)', status: 'COMPLETED' },
    { step: 5, stage: 'Historical Incidents', description: 'Work order 2025-11-10: Shaft coupling rebalanced by R. Sharma', status: 'COMPLETED' },
    { step: 6, stage: 'Sensor Trend Analysis', description: 'Temperature +14% 7-day trend; Vibration +21% 7-day trend', status: 'COMPLETED' },
    { step: 7, stage: 'Vision Inspection', description: 'Computer vision identified roller bearing race micro-pitting', status: 'COMPLETED' },
    { step: 8, stage: 'Hypotheses Generated', description: '3 potential root causes formulated by LangGraph Supervisor Agent', status: 'COMPLETED' },
    { step: 9, stage: 'Evidence Verification', description: 'Cross-referenced visual pitting with 94.5°C thermal hotspot & manual', status: 'COMPLETED' },
    { step: 10, stage: 'Ranked Hypotheses', description: 'Hypothesis A (87% confidence); Hypothesis B (62%); Hypothesis C (25%)', status: 'COMPLETED' },
    { step: 11, stage: 'Root Cause Determined', description: 'Double-Row Cylindrical Roller Bearing race surface pitting', status: 'COMPLETED' },
    { step: 12, stage: 'Action Recommended', description: 'Schedule immediate lube refresh and bearing replacement within 72 hrs', status: 'COMPLETED' },
    { step: 13, stage: 'Audit Trail Logged', description: 'Persisted investigation report in local SQL database', status: 'COMPLETED' }
  ]);

  const [hypotheses, setHypotheses] = useState([
    {
      rank: 1,
      cause: 'Roller Bearing Race Surface Pitting & Degradation',
      confidence: 0.87,
      status: 'MOST_PROBABLE',
      evidence: [
        'Computer vision identified micro-pitting on roller race (89% confidence)',
        'Thermal hotspot at drive end (94.5°C exceeds safety limit 85.0°C)',
        'RAG manual page 2 lists thermal rise + vibration as primary bearing wear signature'
      ]
    },
    {
      rank: 2,
      cause: 'Synthetic Lubricant Thermal Breakdown & Viscosity Loss',
      confidence: 0.62,
      status: 'CONTRIBUTING_FACTOR',
      evidence: [
        'Last lubrication service performed 180 days ago (2025-08-22)',
        'Continuous high temperature accelerates lube oxidation'
      ]
    },
    {
      rank: 3,
      cause: 'Drive Shaft Coupling Misalignment',
      confidence: 0.25,
      status: 'UNLIKELY',
      evidence: [
        'Coupling was rebalanced on 2025-11-10',
        'Pressure signal remains stable at 112 PSI'
      ]
    }
  ]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950/40 border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs tracking-wider uppercase">
            <SearchCheck className="w-4 h-4" />
            <span>Autonomous Root Cause Engine</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">AI Root Cause Investigation Mode</h2>
          <p className="text-xs text-slate-400">
            Multi-agent hypothesis generation, evidence verification, and root cause determination across all data modalities.
          </p>
        </div>
        <button className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-lg shadow-cyan-500/20 flex items-center gap-2 transition">
          <Sparkles className="w-4 h-4" />
          <span>Execute New AI Investigation</span>
        </button>
      </div>

      {/* Main Investigation Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Hypotheses & Evidence */}
        <div className="lg:col-span-2 space-y-6">
          {/* Probable Root Cause Banner */}
          <div className="glass-panel p-5 rounded-2xl border-cyan-500/30 bg-gradient-to-br from-slate-950 via-slate-900 to-cyan-950/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">Determined Root Cause</span>
              <span className="text-xs font-bold px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                Confidence: 87.0%
              </span>
            </div>
            <h3 className="text-lg font-bold text-white">
              Double-Row Cylindrical Roller Bearing race surface pitting leading to mechanical friction & thermal breakdown.
            </h3>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-1">
              <div className="font-bold text-amber-400 flex items-center gap-1">
                <Wrench className="w-3.5 h-3.5" />
                <span>Recommended Engineering Action:</span>
              </div>
              <p>Schedule physical inspection within 48 hours. Inject ISO VG 320 lubricant and replace roller race assembly during next planned shutdown.</p>
            </div>
          </div>

          {/* Ranked Hypotheses Cards */}
          <div className="glass-panel p-5 rounded-2xl space-y-4 border-slate-800">
            <h3 className="text-base font-bold text-white">Ranked Hypotheses & Evidence Verification</h3>

            <div className="space-y-4">
              {hypotheses.map((h) => (
                <div key={h.rank} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-slate-800 text-cyan-400 flex items-center justify-center font-bold text-xs">
                        #{h.rank}
                      </span>
                      <span className="font-bold text-sm text-slate-100">{h.cause}</span>
                    </div>
                    <span
                      className={`text-[10px] font-bold px-2.5 py-0.5 rounded border ${
                        h.status === 'MOST_PROBABLE'
                          ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
                          : h.status === 'CONTRIBUTING_FACTOR'
                          ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                          : 'bg-slate-800 text-slate-400 border-slate-700'
                      }`}
                    >
                      {h.status} ({h.confidence * 100}%)
                    </span>
                  </div>

                  <div className="space-y-1.5 text-xs">
                    <div className="text-slate-400 font-semibold">Verified Evidence Base:</div>
                    {h.evidence.map((ev, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-slate-300 text-[11px]">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{ev}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: 13-Step Investigation Timeline */}
        <div className="glass-panel p-5 rounded-2xl space-y-4 border-slate-800">
          <h3 className="text-base font-bold text-white">Investigation Execution Timeline</h3>

          <div className="space-y-3">
            {timeline.map((item) => (
              <div key={item.step} className="flex items-start gap-3 text-xs">
                <div className="w-6 h-6 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                  {item.step}
                </div>
                <div className="space-y-0.5">
                  <div className="font-bold text-slate-200">{item.stage}</div>
                  <div className="text-[11px] text-slate-400 leading-tight">{item.description}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
