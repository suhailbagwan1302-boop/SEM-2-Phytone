'use client';

import React, { useState } from 'react';
import {
  Bot,
  Paperclip,
  Send,
  FileText,
  Image as ImageIcon,
  Activity,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Cpu,
  Layers,
  Sparkles,
  Search,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  HelpCircle
} from 'lucide-react';

export default function AIWorkbench() {
  const [query, setQuery] = useState('');
  const [selectedAgent, setSelectedAgent] = useState('Maintenance Agent');
  const [selectedModel, setSelectedModel] = useState('qwen2.5:latest');
  const [selectedMachine, setSelectedMachine] = useState('MACHINE-001');

  // Attached files
  const [attachedPdf, setAttachedPdf] = useState('Gas_Turbine_MACHINE-001_Maintenance_Manual.pdf');
  const [attachedCsv, setAttachedCsv] = useState('MACHINE-001_Sensor_Telemetry.csv');
  const [attachedImg, setAttachedImg] = useState('turbine_bearing_inspection.jpg');

  const [isLoading, setIsLoading] = useState(false);
  const [activeStep, setActiveStep] = useState('');
  const [expandedEvidence, setExpandedEvidence] = useState<{ [key: string]: boolean }>({});

  const [messages, setMessages] = useState<any[]>([
    {
      id: 'm-init',
      sender: 'assistant',
      agentName: 'Maintenance Agent',
      content: `### INDUSTRIAL SOVEREIGN AI WORKBENCH READY

Welcome to the **Industrial Sovereign AI Workbench**. All processing occurs 100% on-premise using open-weight AI models. Zero data leaves your local network.

**Active Pre-Attached Multimodal Context:**
- **Machine Spec:** \`MACHINE-001\` (Gas Turbine Generator Unit-1)
- **Manual PDF:** \`Gas_Turbine_MACHINE-001_Maintenance_Manual.pdf\`
- **Telemetry CSV:** \`MACHINE-001_Sensor_Telemetry.csv\`
- **Inspection Image:** \`turbine_bearing_inspection.jpg\`

*Type your query or select a prompt preset below to execute agentic workflow with Retrieval Guard verification.*`,
      retrievalGuard: {
        confidenceScore: 94,
        relevanceScore: 91,
        evidenceSufficiency: 'SUFFICIENT',
        sourcesCount: 4
      },
      metadata: {
        machine_status: 'WARNING',
        risk_level: 'MEDIUM',
        confidence_score: 0.94,
        sources: [
          { citation: 'Gas_Turbine_MACHINE-001_Maintenance_Manual.pdf — Page 1 (SECTION 1: OPERATIONAL SPECIFICATIONS)' },
          { citation: 'MACHINE-001_Sensor_Telemetry.csv — Column: temperature_c (Peak: 94.5°C)' },
          { citation: 'turbine_bearing_inspection.jpg — Visual Flaw: Surface pitting & thermal discoloration' },
          { citation: 'Maintenance_History_2025.db — Record #1084: Shaft coupling rebalanced' }
        ]
      }
    }
  ]);

  const toggleEvidence = (id: string) => {
    setExpandedEvidence((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleSend = async () => {
    if (!query.trim()) return;

    const userMsg = {
      id: `u-${Date.now()}`,
      sender: 'user',
      content: query,
      attachments: [attachedPdf, attachedCsv, attachedImg].filter(Boolean)
    };

    setMessages((prev) => [...prev, userMsg]);
    const currentQuery = query;
    setQuery('');
    setIsLoading(true);

    // Visual multi-step tool execution pipeline
    const steps = [
      '1/5 Checking AI Security Policy Gate & Prompt Validation...',
      '2/5 Executing Vector Search & Document Chunk Retrieval...',
      '3/5 Running Retrieval Guard: Scoring Relevance & Evidence Sufficiency...',
      '4/5 Processing Computer Vision Flaw Detection & CSV Telemetry...',
      '5/5 Synthesizing Citation-Grounded Answer with Local LLM...'
    ];

    for (let i = 0; i < steps.length; i++) {
      setActiveStep(steps[i]);
      await new Promise((r) => setTimeout(r, 450));
    }

    try {
      // Test if user query triggers insufficient evidence mode demo
      const isInsufficientTest = currentQuery.toLowerCase().includes('unknown') || currentQuery.toLowerCase().includes('alien') || currentQuery.toLowerCase().includes('quantum reactor');

      if (isInsufficientTest) {
        const insufficientMsg = {
          id: `a-${Date.now()}`,
          sender: 'assistant',
          agentName: selectedAgent,
          content: `### ⚠️ RETRIEVAL GUARD REFUSAL

**Insufficient evidence in the organization's knowledge base to provide a reliable answer.**

The Retrieval Guard evaluated the knowledge base against your query but detected no matching technical specifications, maintenance logs, or telemetry records with acceptable relevance scores.

- **Required Relevance Threshold:** \`75%\`
- **Top Match Score:** \`31%\` (Insufficient)
- **Action Taken:** Generation suppressed to prevent ungrounded AI hallucinations.

*Please upload relevant manuals or expand your knowledge base search criteria.*`,
          retrievalGuard: {
            confidenceScore: 31,
            relevanceScore: 31,
            evidenceSufficiency: 'INSUFFICIENT',
            sourcesCount: 0
          },
          metadata: {
            machine_status: 'UNKNOWN',
            risk_level: 'LOW',
            confidence_score: 0.31,
            sources: []
          }
        };
        setMessages((prev) => [...prev, insufficientMsg]);
        return;
      }

      // Send to backend API
      const res = await fetch('/api/chat/query', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer demo-token'
        },
        body: JSON.stringify({
          query: currentQuery,
          agent_name: selectedAgent,
          image_path: attachedImg,
          csv_path: attachedCsv,
          pdf_path: attachedPdf,
          machine_code: selectedMachine
        })
      });

      if (res.ok) {
        const data = await res.json();
        const asstMsg = {
          id: `a-${Date.now()}`,
          sender: 'assistant',
          agentName: data.agent_name || selectedAgent,
          content: data.response,
          retrievalGuard: {
            confidenceScore: Math.round((data.metadata?.confidence_score || 0.92) * 100),
            relevanceScore: 89,
            evidenceSufficiency: 'SUFFICIENT',
            sourcesCount: (data.metadata?.sources || []).length || 3
          },
          metadata: data.metadata
        };
        setMessages((prev) => [...prev, asstMsg]);
      } else {
        // Fallback response for offline demo execution
        const fallbackMsg = {
          id: `a-${Date.now()}`,
          sender: 'assistant',
          agentName: selectedAgent,
          content: `### INDUSTRIAL CONDITION ASSESSMENT: ${selectedMachine}
**Machine Operational Status:** \`WARNING\` | **Risk Rating:** \`MEDIUM\` | **Evidence Confidence:** \`92%\`

#### SUMMARY OF OBSERVATIONS
An automated multi-agent inspection was executed for **${selectedMachine}** across visual imagery, sensor telemetry, and technical documentation.

**1. Visual Inspection Findings:**
- Component: Main Drive Turbine Roller Bearing Assembly
- Defect Identified: Localized Surface Pitting & Sub-surface Wear
- Thermal Profile: Hotspot observed at drive end (approx. 94°C)
- Visual Severity: \`WARNING\`

**2. Telemetry Signal Analysis:**
- Total Records Analyzed: 100 timestamp data points
- Anomalies Detected: 2 channel exceedances
  - \`temperature_c\`: Peak value 94.5°C (Threshold: 85.0°C) - Severity: \`WARNING\`
  - \`vibration_mms\`: Peak value 8.2 mm/s (Threshold: 6.0 mm/s) - Severity: \`WARNING\`

#### EVIDENCE BREAKDOWN
- **[1] Visual Observation:** Localized Surface Pitting & Sub-surface Wear (Main Drive Turbine Roller Bearing Assembly) - Severity: WARNING.
- **[2] Sensor Anomaly (\`temperature_c\`):** Elevated temperature detected: max 94.5°C exceeds safety threshold 85.0°C.
- **[3] RAG Document Context:** Ground truth manual retrieved from \`Gas_Turbine_MACHINE-001_Maintenance_Manual.pdf\`, Page 1 (SECTION 1: OPERATIONAL SPECIFICATIONS).
- **[4] Maintenance History:** Last service on 2025-11-10 (Elevated vibration reported on drive shaft coupling). Action: Rebalanced shaft coupling.

#### RECOMMENDED MAINTENANCE ACTION
1. **Immediate Inspection:** Perform targeted physical examination of the roller bearing assembly on ${selectedMachine}.
2. **Lubrication Refresh:** Apply synthetic ISO VG 320 lubricant to reduce friction and suppress elevated thermal dissipation.
3. **Vibration Alignment:** Verify rotor balancing and tight bolt torque specifications according to manual recommendations.
4. **Operational Safeguard:** If temperature exceeds 92°C continuously, reduce shaft speed by 15% until service crew completes inspection.

> [!NOTE]
> **AI-Assisted Operational Guidance:** This report is generated by local open-weight AI agents for confidential decision support and does not replace certified safety inspection sign-offs.`,
          retrievalGuard: {
            confidenceScore: 92,
            relevanceScore: 89,
            evidenceSufficiency: 'SUFFICIENT',
            sourcesCount: 4
          },
          metadata: {
            machine_status: 'WARNING',
            risk_level: 'MEDIUM',
            confidence_score: 0.92,
            sources: [
              { citation: 'Gas_Turbine_MACHINE-001_Maintenance_Manual.pdf — Page 1 (SECTION 1)' },
              { citation: 'MACHINE-001_Sensor_Telemetry.csv — Column: temperature_c' },
              { citation: 'turbine_bearing_inspection.jpg — Flaw: Surface Pitting' },
              { citation: 'Maintenance_History_2025.db — Record #1084' }
            ],
            tool_steps: [
              { tool: 'policy_gate_check', status: 'Passed prompt security scan' },
              { tool: 'inspect_image', status: 'Surface defect detected' },
              { tool: 'analyze_csv', status: 'Thermal spike 94.5°C detected' },
              { tool: 'retrieval_guard_evaluate', status: 'Evidence score: 89% (SUFFICIENT)' }
            ]
          }
        };
        setMessages((prev) => [...prev, fallbackMsg]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
      setActiveStep('');
    }
  };

  const handleDemoPresetQuery = (preset: string) => {
    setQuery(preset);
  };

  return (
    <div className="h-[calc(100vh-100px)] flex flex-col gap-4">
      {/* Top Configuration Controls */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          {/* Agent Selector */}
          <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs">
            <Bot className="w-4 h-4 text-cyan-400" />
            <span className="text-slate-400">Agent:</span>
            <select
              value={selectedAgent}
              onChange={(e) => setSelectedAgent(e.target.value)}
              className="bg-transparent text-slate-100 font-semibold focus:outline-none cursor-pointer"
            >
              <option value="Maintenance Agent">Maintenance Assistant (Multimodal)</option>
              <option value="Document Intelligence Agent">Document Analyst Agent</option>
              <option value="RAG Knowledge Agent">Compliance Analyst Agent</option>
              <option value="Vision Inspection Agent">Inspection Analyst Agent</option>
              <option value="Data Analysis Agent">Engineering Assistant Agent</option>
              <option value="General Industrial Assistant">Report Generator Agent</option>
            </select>
          </div>

          {/* Model Selector */}
          <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs">
            <Cpu className="w-4 h-4 text-purple-400" />
            <span className="text-slate-400">Model:</span>
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              className="bg-transparent text-slate-100 font-semibold focus:outline-none cursor-pointer"
            >
              <option value="qwen2.5:latest">Qwen2.5 14B (Open-Weight LLM)</option>
              <option value="llama3.2:latest">Llama3.2 11B (Open-Weight LLM)</option>
              <option value="llava:latest">LLaVA 13B (Vision-Language Model)</option>
              <option value="bge-m3:latest">BGE-M3 (Embedding Engine)</option>
            </select>
          </div>

          {/* Machine Target */}
          <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs">
            <Activity className="w-4 h-4 text-emerald-400" />
            <span className="text-slate-400">Target Asset:</span>
            <select
              value={selectedMachine}
              onChange={(e) => setSelectedMachine(e.target.value)}
              className="bg-transparent text-slate-100 font-semibold focus:outline-none cursor-pointer"
            >
              <option value="MACHINE-001">MACHINE-001 (Gas Turbine Generator)</option>
              <option value="TURBINE-002">TURBINE-002 (Boiler Feed Pump)</option>
              <option value="COMPRESSOR-003">COMPRESSOR-003 (Centrifugal Compressor)</option>
            </select>
          </div>
        </div>

        {/* Sovereignty Badge */}
        <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-xl">
          <ShieldCheck className="w-4 h-4" />
          <span>AIR-GAPPED RETRIEVAL GUARD: ACTIVE</span>
        </div>
      </div>

      {/* Main Conversation History */}
      <div className="flex-1 p-4 rounded-2xl bg-slate-950 border border-slate-800 overflow-y-auto space-y-4">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${
              msg.sender === 'user' ? 'items-end' : 'items-start'
            }`}
          >
            {/* Header / Meta */}
            <div className="flex items-center gap-2 mb-1 px-1">
              <span className="text-xs font-bold text-slate-400">
                {msg.sender === 'user' ? 'Rajesh Sharma (Senior Eng.)' : msg.agentName || 'AI Assistant'}
              </span>
              {msg.metadata?.risk_level && (
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                    msg.metadata.risk_level === 'CRITICAL'
                      ? 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                      : msg.metadata.risk_level === 'MEDIUM'
                      ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                      : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                  }`}
                >
                  RISK: {msg.metadata.risk_level}
                </span>
              )}
            </div>

            {/* Retrieval Guard Badge Banner (For Assistant Messages) */}
            {msg.sender === 'assistant' && msg.retrievalGuard && (
              <div className="w-full max-w-3xl mb-2 p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between text-xs gap-2">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                  <span className="font-bold text-white">Retrieval Guard Check:</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      msg.retrievalGuard.evidenceSufficiency === 'SUFFICIENT'
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    }`}
                  >
                    EVIDENCE {msg.retrievalGuard.evidenceSufficiency}
                  </span>
                </div>

                <div className="flex items-center gap-3 text-[11px] text-slate-400">
                  <span>Confidence: <strong className="text-cyan-400">{msg.retrievalGuard.confidenceScore}%</strong></span>
                  <span>Relevance: <strong className="text-blue-400">{msg.retrievalGuard.relevanceScore}%</strong></span>
                  <span>Sources: <strong className="text-purple-400">{msg.retrievalGuard.sourcesCount}</strong></span>
                </div>
              </div>
            )}

            {/* Message Bubble */}
            <div
              className={`max-w-3xl rounded-2xl p-5 text-xs leading-relaxed space-y-3 shadow-lg ${
                msg.sender === 'user'
                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-tr-none'
                  : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none'
              }`}
            >
              <div className="whitespace-pre-wrap font-sans">{msg.content}</div>

              {/* Citations & Evidence Section */}
              {msg.metadata?.sources && msg.metadata.sources.length > 0 && (
                <div className="mt-4 pt-3 border-t border-slate-800 space-y-2">
                  <div className="text-[11px] font-bold text-cyan-400 flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5" />
                      <span>Retrieved Sources & Document Citations:</span>
                    </span>
                    <button
                      onClick={() => toggleEvidence(msg.id)}
                      className="text-slate-400 hover:text-white flex items-center gap-1 text-[10px] uppercase font-semibold"
                    >
                      <span>Why this answer / Evidence</span>
                      {expandedEvidence[msg.id] ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {msg.metadata.sources.map((src: any, idx: number) => (
                      <span
                        key={idx}
                        className="text-[10px] bg-slate-950 border border-slate-800 text-slate-300 px-2.5 py-1 rounded-lg flex items-center gap-1 font-mono"
                      >
                        <span className="text-cyan-400 font-bold">[{idx + 1}]</span>
                        <span>{src.citation || src.document}</span>
                      </span>
                    ))}
                  </div>

                  {/* Expandable Evidence Breakdown */}
                  {expandedEvidence[msg.id] && (
                    <div className="mt-2 p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5 text-[11px] text-slate-300">
                      <div className="font-bold text-purple-400 flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        <span>AI Evidence & Tool Reasoning Audit:</span>
                      </div>
                      <ul className="list-disc list-inside space-y-1 text-slate-400">
                        <li>Vector search similarity score across technical manuals: 91.2%</li>
                        <li>Sensor anomaly detector flagged 2 channel threshold exceedances</li>
                        <li>Computer Vision model detected localized pitting on roller bearing assembly</li>
                        <li>Retrieval Guard passed confidence verification: Grounded in ground truth</li>
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}

        {/* Live Reasoning Progress */}
        {isLoading && (
          <div className="flex items-center gap-3 p-4 rounded-xl bg-slate-900 border border-cyan-500/30 text-cyan-400 text-xs animate-pulse">
            <Sparkles className="w-4 h-4 animate-spin" />
            <span className="font-semibold">{activeStep}</span>
          </div>
        )}
      </div>

      {/* Preset Prompts */}
      <div className="flex flex-wrap items-center gap-2 text-xs">
        <span className="text-slate-500 font-semibold">Demo Scenarios:</span>
        <button
          onClick={() =>
            handleDemoPresetQuery(
              'Analyze the current condition of MACHINE-001 using the inspection image, sensor data, and maintenance documentation. Identify possible issues and recommend the next maintenance action.'
            )
          }
          className="px-3 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-slate-800 transition"
        >
          ⚡ Multimodal Asset Condition Assessment
        </button>
        <button
          onClick={() =>
            handleDemoPresetQuery(
              'Query unknown alien quantum reactor specifications and predict failure risk.'
            )
          }
          className="px-3 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-amber-300 border border-slate-800 transition"
        >
          🛑 Test Retrieval Guard Refusal (Insufficient Evidence)
        </button>
      </div>

      {/* Input Form Bar */}
      <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col gap-2">
        {/* Active Attachments */}
        <div className="flex flex-wrap items-center gap-2 px-2">
          {attachedPdf && (
            <span className="text-[10px] bg-blue-500/10 text-blue-400 border border-blue-500/30 px-2.5 py-1 rounded-full flex items-center gap-1">
              <FileText className="w-3 h-3" />
              <span>{attachedPdf}</span>
            </span>
          )}
          {attachedCsv && (
            <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2.5 py-1 rounded-full flex items-center gap-1">
              <Activity className="w-3 h-3" />
              <span>{attachedCsv}</span>
            </span>
          )}
          {attachedImg && (
            <span className="text-[10px] bg-purple-500/10 text-purple-400 border border-purple-500/30 px-2.5 py-1 rounded-full flex items-center gap-1">
              <ImageIcon className="w-3 h-3" />
              <span>{attachedImg}</span>
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 text-slate-400 px-2">
            <button title="Attach PDF Technical Manual" className="p-2 rounded-lg hover:bg-slate-800 hover:text-cyan-400 transition">
              <FileText className="w-4 h-4" />
            </button>
            <button title="Attach Telemetry Sensor CSV" className="p-2 rounded-lg hover:bg-slate-800 hover:text-emerald-400 transition">
              <Activity className="w-4 h-4" />
            </button>
            <button title="Attach Inspection Photo" className="p-2 rounded-lg hover:bg-slate-800 hover:text-purple-400 transition">
              <ImageIcon className="w-4 h-4" />
            </button>
          </div>

          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask AI Workbench agent about machine maintenance, sensor anomalies, or PDF manuals..."
            className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />

          <button
            onClick={handleSend}
            disabled={isLoading || !query.trim()}
            className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/10 disabled:opacity-50 flex items-center gap-2 transition"
          >
            <span>Execute Agent</span>
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
