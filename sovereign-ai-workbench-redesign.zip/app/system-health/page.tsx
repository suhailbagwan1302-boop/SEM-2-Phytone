'use client';

import React from 'react';
import {
  Activity,
  Server,
  Database,
  Cpu,
  ShieldCheck,
  CheckCircle2,
  HardDrive,
  Clock,
  Zap,
  BarChart2
} from 'lucide-react';

export default function SystemHealthPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl bg-slate-950 border border-slate-800 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs tracking-wider uppercase">
            <Activity className="w-4 h-4" />
            <span>Infrastructure Telemetry & Observability</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">System Observability & Performance Monitoring</h2>
          <p className="text-xs text-slate-400 max-w-2xl">
            Real-time telemetry for CPU, RAM, GPU, LLM inference latency, RAG retrieval latency, vector search throughput, and microservice error rates.
          </p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>ALL SYSTEM MICROSERVICES ONLINE</span>
        </div>
      </div>

      {/* Latency & Throughput Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold">
            <span>LLM Inference Latency</span>
            <Cpu className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-cyan-400">420 ms</div>
          <div className="text-[11px] text-slate-400">Qwen2.5 14B / Ollama Engine</div>
        </div>

        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold">
            <span>RAG Vector Search Latency</span>
            <Database className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-blue-400">18 ms</div>
          <div className="text-[11px] text-slate-400">BGE-M3 1024d Dense Search</div>
        </div>

        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold">
            <span>Agent Workflow Latency</span>
            <Zap className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-purple-400">840 ms</div>
          <div className="text-[11px] text-slate-400">Multi-Tool Reasoning Loop</div>
        </div>

        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold">
            <span>Token Generation Rate</span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400">48.2 tok/s</div>
          <div className="text-[11px] text-slate-400">Local Hardware Acceleration</div>
        </div>
      </div>

      {/* Microservice Health Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-300">FastAPI API Gateway</span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              ONLINE
            </span>
          </div>
          <div className="text-xl font-bold text-white">12 ms API Response</div>
          <div className="text-[11px] text-slate-400">Port 8000 | Zero External API</div>
        </div>

        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-300">SQL Database Engine</span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              ONLINE
            </span>
          </div>
          <div className="text-xl font-bold text-white">4 ms DB Query</div>
          <div className="text-[11px] text-slate-400">SQLAlchemy / SQLite Local</div>
        </div>

        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-300">Vector Storage DB</span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              ONLINE
            </span>
          </div>
          <div className="text-xl font-bold text-white">480 Vector Chunks</div>
          <div className="text-[11px] text-slate-400">ChromaDB Local Persistence</div>
        </div>

        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-300">Model Engine (Ollama)</span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              ONLINE
            </span>
          </div>
          <div className="text-xl font-bold text-white">Port 11434</div>
          <div className="text-[11px] text-slate-400">Qwen2.5 / LLaVA Local</div>
        </div>
      </div>

      {/* Hardware Utilization Telemetry Meters */}
      <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-5 shadow-xl">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <HardDrive className="w-4 h-4 text-purple-400" />
          <span>Hardware Resource Utilization Telemetry</span>
        </h3>

        <div className="space-y-4 text-xs">
          {/* CPU Meter */}
          <div className="space-y-1.5">
            <div className="flex justify-between font-semibold">
              <span className="text-slate-300">CPU Processor Load</span>
              <span className="text-cyan-400 font-mono">18.4%</span>
            </div>
            <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden border border-slate-800">
              <div className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full w-[18.4%]" />
            </div>
          </div>

          {/* GPU VRAM Meter */}
          <div className="space-y-1.5">
            <div className="flex justify-between font-semibold">
              <span className="text-slate-300">GPU VRAM Allocation (NVIDIA RTX / Local Accelerator)</span>
              <span className="text-purple-400 font-mono">32.1% (8.0 GB / 24.0 GB)</span>
            </div>
            <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden border border-slate-800">
              <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-full w-[32.1%]" />
            </div>
          </div>

          {/* System Memory RAM Meter */}
          <div className="space-y-1.5">
            <div className="flex justify-between font-semibold">
              <span className="text-slate-300">System RAM Usage</span>
              <span className="text-emerald-400 font-mono">6.8 GB / 16.0 GB</span>
            </div>
            <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden border border-slate-800">
              <div className="bg-gradient-to-r from-emerald-500 to-cyan-500 h-full w-[42.5%]" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
