import React from 'react';
import './globals.css';
import SovereigntyHeader from '@/components/SovereigntyHeader';
import Sidebar from '@/components/Sidebar';
import CommandOverlays from '@/components/CommandOverlays';

export const metadata = {
  title: 'Sovereign On-Premise Agentic AI Workbench | SIH 2026',
  description: 'Confidential Industrial AI Workbench for local open-weight multimodal model inference.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="app-body">
        <SovereigntyHeader />
        <div className="app-frame">
          <Sidebar />
          <main className="app-main">
            {children}
          </main>
        </div>
        <CommandOverlays />
      </body>
    </html>
  );
}
