'use client';

import React, { useState } from 'react';
import {
  Eye,
  Upload,
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Camera,
  Layers,
  Wrench,
  FileCheck
} from 'lucide-react';

export default function VisualInspectionPage() {
  const [imagePreview, setImagePreview] = useState<string | null>(
    'https://images.unsplash.com/photo-1581092160607-ee22621dd758?q=80&w=800&auto=format&fit=crop'
  );
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState({
    component: 'Main Drive Turbine Roller Bearing Assembly',
    defect: 'Localized Surface Pitting & Sub-surface Wear',
    severity: 'WARNING',
    confidence: 0.89,
    thermalSignature: 'Drive End Hotspot (94.5°C)',
    recommendedAction: 'Schedule bearing race replacement during upcoming maintenance shutdown and re-apply ISO VG 320 lubricant within 72 hours.',
    disclaimer: 'AI-Assisted Visual Inspection. Not a certified safety diagnosis.'
  });

  const handleRunInspection = () => {
    setIsAnalyzing(true);
    setTimeout(() => {
      setIsAnalyzing(false);
    }, 800);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-pink-950/40 border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center gap-2 text-pink-400 font-semibold text-xs tracking-wider uppercase">
            <Eye className="w-4 h-4" />
            <span>Computer Vision Subsystem</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Visual Inspection Studio</h2>
          <p className="text-xs text-slate-400">
            Open-weight Multimodal Vision-Language Model (LLaVA / Qwen-VL) flaw detection & defect severity scoring.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-bold text-xs shadow-lg shadow-pink-500/20 flex items-center gap-2 transition">
            <Upload className="w-4 h-4" />
            <span>Upload Inspection Photo</span>
          </button>
        </div>
      </div>

      {/* Main Inspection Canvas */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Image Viewer */}
        <div className="glass-panel p-5 rounded-2xl space-y-4 border-slate-800">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Camera className="w-4 h-4 text-pink-400" />
              <span>Inspection Image Canvas</span>
            </h3>
            <span className="text-xs text-slate-400">MACHINE-001 Bearing</span>
          </div>

          <div className="relative rounded-xl overflow-hidden bg-slate-950 border border-slate-800 h-80 flex items-center justify-center group">
            {imagePreview ? (
              <img
                src={imagePreview}
                alt="Industrial Inspection"
                className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
              />
            ) : (
              <div className="text-slate-500 text-xs flex flex-col items-center gap-2">
                <Camera className="w-8 h-8 stroke-1" />
                <span>Upload an image to start visual inspection</span>
              </div>
            )}

            {/* Simulated Bounding Box Overlay */}
            <div className="absolute top-1/3 left-1/4 w-36 h-28 border-2 border-amber-400 bg-amber-500/10 rounded-lg pointer-events-none flex flex-col justify-between p-1">
              <span className="text-[9px] font-bold bg-amber-500 text-slate-950 px-1 rounded w-max">
                ANOMALY: PITTING (89%)
              </span>
            </div>
          </div>

          <button
            onClick={handleRunInspection}
            disabled={isAnalyzing}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-pink-600 via-purple-600 to-cyan-600 text-white font-bold text-xs shadow-lg shadow-pink-500/20 flex items-center justify-center gap-2 transition"
          >
            <Sparkles className="w-4 h-4 animate-spin" />
            <span>{isAnalyzing ? 'Running Local Multimodal Vision Inspection...' : 'Re-Run Computer Vision Check'}</span>
          </button>
        </div>

        {/* Right: AI Analysis Results */}
        <div className="glass-panel p-5 rounded-2xl space-y-5 border-slate-800">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-base font-bold text-white">Multimodal Vision Diagnostics</h3>
              <p className="text-xs text-slate-400">Computer vision observation breakdown</p>
            </div>
            <span
              className={`text-xs font-bold px-3 py-1 rounded-full border ${
                analysisResult.severity === 'CRITICAL'
                  ? 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                  : analysisResult.severity === 'WARNING'
                  ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                  : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
              }`}
            >
              SEVERITY: {analysisResult.severity}
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <div className="text-slate-400 font-medium">Component Identified:</div>
              <div className="text-slate-100 font-bold">{analysisResult.component}</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <div className="text-slate-400 font-medium">Visual Defect Detected:</div>
              <div className="text-amber-400 font-bold">{analysisResult.defect}</div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <div className="text-slate-400 font-medium">Model Confidence:</div>
                <div className="text-cyan-400 font-bold">{(analysisResult.confidence * 100).toFixed(1)}%</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <div className="text-slate-400 font-medium">Thermal Signature:</div>
                <div className="text-rose-400 font-bold">{analysisResult.thermalSignature}</div>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-cyan-500/30 space-y-1">
              <div className="text-cyan-400 font-bold flex items-center gap-1.5">
                <Wrench className="w-4 h-4" />
                <span>Recommended Maintenance Action:</span>
              </div>
              <p className="text-slate-200 leading-relaxed">{analysisResult.recommendedAction}</p>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{analysisResult.disclaimer}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
