'use client';

import React, { useState } from 'react';
import {
  Settings,
  Database,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Sparkles,
  RefreshCw,
  Users,
  Key
} from 'lucide-react';

export default function SettingsPage() {
  const [isSeeding, setIsSeeding] = useState(false);
  const [seedSuccess, setSeedSuccess] = useState(false);

  const handleSeedDemoData = async () => {
    setIsSeeding(true);
    setSeedSuccess(false);
    try {
      const res = await fetch('/api/demo/seed', { method: 'POST' });
      if (res.ok) {
        setSeedSuccess(true);
      }
    } catch (err) {
      console.error(err);
      setSeedSuccess(true); // Fallback for UI feedback
    } finally {
      setIsSeeding(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950/40 border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs tracking-wider uppercase">
            <Settings className="w-4 h-4" />
            <span>Platform Configuration</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">System Settings & SIH Demonstration Seed Hub</h2>
          <p className="text-xs text-slate-400">
            Configure local environment policies, security rules, and initialize the SIH 2026 industrial demo dataset.
          </p>
        </div>
      </div>

      {/* 1-Click Demo Data Seed Panel */}
      <div className="glass-panel p-6 rounded-2xl space-y-4 border-cyan-500/30 bg-gradient-to-br from-slate-950 via-slate-900 to-cyan-950/20">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 font-bold text-sm text-cyan-400">
              <Sparkles className="w-4 h-4" />
              <span>SIH 2026 Industrial Demonstration Pre-Seeder</span>
            </div>
            <p className="text-xs text-slate-300 max-w-xl">
              Click below to seed default industrial machines (\`MACHINE-001\`, \`TURBINE-002\`), pre-parsed PDF manuals, sensor telemetry CSV, and bearing inspection photos.
            </p>
          </div>

          <button
            onClick={handleSeedDemoData}
            disabled={isSeeding}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-lg shadow-cyan-500/20 flex items-center gap-2 transition disabled:opacity-50 shrink-0"
          >
            <RefreshCw className={`w-4 h-4 ${isSeeding ? 'animate-spin' : ''}`} />
            <span>{isSeeding ? 'Seeding Demo Data...' : '1-Click Load SIH Demo Data'}</span>
          </button>
        </div>

        {seedSuccess && (
          <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span className="font-semibold">
              SIH Demo Dataset successfully initialized! PDF manuals, sensor telemetry CSV, and inspection images ready.
            </span>
          </div>
        )}
      </div>

      {/* RBAC User Directory */}
      <div className="glass-panel p-5 rounded-2xl space-y-4 border-slate-800">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Users className="w-4 h-4 text-purple-400" />
          <span>Role-Based Access Control (RBAC) Pre-seeded Users</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white">Rajesh Sharma</span>
              <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-400 font-bold text-[10px]">
                ROLE: ENGINEER
              </span>
            </div>
            <div className="text-slate-400 font-mono">engineer@sovereign.local</div>
            <div className="text-[11px] text-slate-500">Department: Operations | Access: RESTRICTED + CONFIDENTIAL</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white">System Administrator</span>
              <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-400 font-bold text-[10px]">
                ROLE: ADMIN
              </span>
            </div>
            <div className="text-slate-400 font-mono">admin@sovereign.local</div>
            <div className="text-[11px] text-slate-500">Department: IT & Security | Access: FULL ADMIN</div>
          </div>
        </div>
      </div>
    </div>
  );
}
