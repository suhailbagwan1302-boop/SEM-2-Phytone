'use client';

import React, { useState } from 'react';
import {
  Lock,
  ShieldCheck,
  AlertCircle,
  Activity,
  UserCheck,
  Key,
  Eye,
  ShieldAlert,
  Server,
  Cpu,
  CheckCircle2,
  XCircle,
  Sliders,
  Sparkles,
  RefreshCw
} from 'lucide-react';

export default function SecurityCenterPage() {
  const [policies, setPolicies] = useState([
    {
      id: 'pol-1',
      name: 'Confidential Data Protection & PII Masking',
      category: 'Data Leakage Safeguard',
      status: 'ENFORCED',
      description: 'Automatically redacts social security, employee IDs, and confidential thermal schematics.',
      mode: 'ACTIVE'
    },
    {
      id: 'pol-2',
      name: 'Prompt Injection & Adversarial Attack Detector',
      category: 'Input Validation',
      status: 'ENFORCED',
      description: 'Filters jailbreak patterns, system prompt overrides, and adversarial instructions.',
      mode: 'ACTIVE'
    },
    {
      id: 'pol-3',
      name: 'Sensitive Document Access Control (RBAC)',
      category: 'Access Control',
      status: 'ENFORCED',
      description: 'Verifies user department clearance before vector chunk retrieval.',
      mode: 'ACTIVE'
    },
    {
      id: 'pol-4',
      name: 'Unsafe AI Tool Execution Prevention',
      category: 'Agent Safeguard',
      status: 'ENFORCED',
      description: 'Blocks autonomous file deletion, unauthorized database mutations, and remote script execution.',
      mode: 'ACTIVE'
    },
    {
      id: 'pol-5',
      name: 'External API & Outbound Socket Firewall',
      category: 'Air-Gapped Isolation',
      status: 'ENFORCED',
      description: 'Drops all TCP/UDP outbound packets to public internet endpoints.',
      mode: 'ACTIVE'
    }
  ]);

  const firewallStages = [
    { step: 1, name: 'USER INPUT', desc: 'Raw prompt intake' },
    { step: 2, name: 'SECURITY SCAN', desc: 'Jailbreak & injection filter' },
    { step: 3, name: 'POLICY CHECK', desc: 'RBAC document clearance' },
    { step: 4, name: 'AI PROCESSING', desc: 'On-premise LLM inference' },
    { step: 5, name: 'OUTPUT SCAN', desc: 'Hallucination & leak check' },
    { step: 6, name: 'FINAL RESPONSE', desc: 'Verified answer delivery' }
  ];

  const togglePolicy = (id: string) => {
    setPolicies((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              mode: p.mode === 'ACTIVE' ? 'PAUSED' : 'ACTIVE',
              status: p.mode === 'ACTIVE' ? 'SUSPENDED' : 'ENFORCED'
            }
          : p
      )
    );
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl bg-slate-950 border border-slate-800 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-rose-400 font-semibold text-xs tracking-wider uppercase">
            <Lock className="w-4 h-4" />
            <span>AI Cybersecurity Guard</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">AI Security & Firewall Center</h2>
          <p className="text-xs text-slate-400 max-w-2xl">
            Real-time monitoring of prompt security, prompt injection detection, data leakage prevention, RBAC clearances, and firewall policy gates.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>THREAT SCORE: 98.5 (SECURE)</span>
          </div>
          <div className="px-2.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 text-[10px] font-bold">
            FIREWALL TELEMETRY — SIMULATED / DEMO
          </div>
        </div>
      </div>

      {/* AI Firewall 6-Step Visual Processing Pipeline */}
      <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            <span>AI Firewall Architecture Pipeline</span>
          </h3>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            DEMO INTERACTIVE PIPELINE
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {firewallStages.map((st) => (
            <div key={st.step} className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1 text-center">
              <div className="text-[10px] font-bold text-slate-500">STAGE {st.step}</div>
              <div className="text-xs font-bold text-slate-200">{st.name}</div>
              <div className="text-[10px] text-slate-400">{st.desc}</div>
              <div className="pt-1">
                <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400">
                  PASSED
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Configurable AI Policy Gates */}
      <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-purple-400" />
              <span>Configurable AI Policy Gates</span>
            </h3>
            <p className="text-xs text-slate-400">Enforce enterprise guardrails between user prompts and local LLM execution</p>
          </div>
          <span className="text-xs text-slate-400">5 Active Policy Guards</span>
        </div>

        <div className="space-y-3">
          {policies.map((pol) => (
            <div
              key={pol.id}
              className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-xs text-white">{pol.name}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-950 text-slate-400 border border-slate-800">
                    {pol.category}
                  </span>
                </div>
                <p className="text-xs text-slate-400">{pol.description}</p>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                    pol.mode === 'ACTIVE'
                      ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                  }`}
                >
                  {pol.status}
                </span>

                <button
                  onClick={() => togglePolicy(pol.id)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                    pol.mode === 'ACTIVE'
                      ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                      : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                  }`}
                >
                  {pol.mode === 'ACTIVE' ? 'Pause Guard' : 'Activate Guard'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Security Event & Audit Stream */}
      <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <span>Real-Time Security Event & Clearance Audit Stream</span>
          </h3>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
            AIR-GAPPED FIREWALL LOGS
          </span>
        </div>

        <div className="space-y-3 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="font-bold text-slate-200">PROMPT_ACCESS_CLEARANCE</div>
              <div className="text-slate-400">User R. Sharma queried MACHINE-001 documentation. Clearance check: CONFIDENTIAL (GRANTED).</div>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              LOW THREAT (PASSED)
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="font-bold text-slate-200">PROMPT_INJECTION_SCAN</div>
              <div className="text-slate-400">Scanned input prompt for system instruction override patterns. Zero malicious tokens detected.</div>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              SECURE
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="font-bold text-slate-200">AIR_GAPPED_NETWORK_VALIDATION</div>
              <div className="text-slate-400">Automated perimeter check confirmed zero outbound cloud socket connections.</div>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              100% PRIVATE
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
