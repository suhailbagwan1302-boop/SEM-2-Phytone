'use client';

import React, { useState } from 'react';
import {
  FileText,
  Upload,
  Shield,
  Trash2,
  Eye,
  CheckCircle2,
  Lock,
  Search,
  Filter,
  Plus
} from 'lucide-react';

const SAMPLE_DOCUMENTS = [
  {
    id: 'doc-1',
    filename: 'Gas_Turbine_MACHINE-001_Maintenance_Manual.pdf',
    size: '2.4 MB',
    department: 'Power Generation',
    classification: 'CONFIDENTIAL',
    chunks: 42,
    status: 'INDEXED',
    date: '2026-08-23 14:10'
  },
  {
    id: 'doc-2',
    filename: 'High_Pressure_Feed_Pump_Specs_TURBINE-002.pdf',
    size: '1.8 MB',
    department: 'Water Treatment',
    classification: 'RESTRICTED',
    chunks: 28,
    status: 'INDEXED',
    date: '2026-08-22 11:45'
  },
  {
    id: 'doc-3',
    filename: 'Standard_Operating_Procedure_Compressor_Safety.docx',
    size: '950 KB',
    department: 'Pneumatics',
    classification: 'INTERNAL',
    chunks: 16,
    status: 'INDEXED',
    date: '2026-08-20 09:30'
  }
];

export default function DocumentsPage() {
  const [documents, setDocuments] = useState(SAMPLE_DOCUMENTS);
  const [selectedDoc, setSelectedDoc] = useState<any>(SAMPLE_DOCUMENTS[0]);
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-blue-950/40 border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center gap-2 text-blue-400 font-semibold text-xs tracking-wider uppercase">
            <FileText className="w-4 h-4" />
            <span>Confidential Ingestion Engine</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Document Intelligence Repository</h2>
          <p className="text-xs text-slate-400">
            Upload PDF, DOCX, and TXT manuals. Text chunks are parsed, indexed, and stored in local vector storage with RBAC clearance tags.
          </p>
        </div>
        <button className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-400 hover:to-cyan-500 text-white font-semibold text-xs shadow-lg shadow-blue-500/20 flex items-center gap-2 transition">
          <Upload className="w-4 h-4" />
          <span>Upload Industrial Manual</span>
        </button>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Document List */}
        <div className="lg:col-span-2 glass-panel p-5 rounded-2xl space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search ingested manuals by name or department..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>
            <span className="text-xs text-slate-400 font-medium">{documents.length} Files</span>
          </div>

          <div className="space-y-3">
            {documents.map((doc) => (
              <div
                key={doc.id}
                onClick={() => setSelectedDoc(doc)}
                className={`p-4 rounded-xl border transition cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-3 ${
                  selectedDoc?.id === doc.id
                    ? 'bg-slate-900 border-cyan-500/50 shadow-lg shadow-cyan-500/10'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-lg bg-blue-500/10 text-blue-400">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div className="space-y-1">
                    <div className="font-bold text-xs text-slate-100">{doc.filename}</div>
                    <div className="flex flex-wrap items-center gap-2 text-[10px] text-slate-400">
                      <span>Size: {doc.size}</span>
                      <span>•</span>
                      <span>Dept: {doc.department}</span>
                      <span>•</span>
                      <span className="text-cyan-400">{doc.chunks} Chunks Indexed</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 justify-between md:justify-end">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                      doc.classification === 'CONFIDENTIAL'
                        ? 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                        : doc.classification === 'RESTRICTED'
                        ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                        : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                    }`}
                  >
                    {doc.classification}
                  </span>
                  <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    ✓ INDEXED
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Document Details & Vector Chunks Inspector */}
        <div className="glass-panel p-5 rounded-2xl space-y-4">
          {selectedDoc ? (
            <>
              <div className="border-b border-slate-800 pb-3 space-y-1">
                <div className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider">Selected Manual</div>
                <h3 className="text-sm font-bold text-white leading-tight">{selectedDoc.filename}</h3>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Security Clearance:</span>
                  <span className="font-bold text-rose-400">{selectedDoc.classification}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Department:</span>
                  <span className="text-slate-200">{selectedDoc.department}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Indexed Vector Chunks:</span>
                  <span className="text-cyan-400 font-bold">{selectedDoc.chunks} Chunks</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Upload Date:</span>
                  <span className="text-slate-300">{selectedDoc.date}</span>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <Eye className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Sample Vector Chunk Inspector</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-300 font-mono space-y-1 leading-relaxed">
                  <div className="text-[10px] text-cyan-400 font-bold">[Chunk 0 | Page 1 | SECTION 1]</div>
                  <p>
                    "Nominal Operating Speed: 3,600 RPM. Continuous Maximum Thermal Rating: 85.0°C. Critical Thermal Limit: 95.0°C. Warning Vibration Limit: 6.0 mm/s."
                  </p>
                </div>
              </div>
            </>
          ) : (
            <div className="text-xs text-slate-500 text-center py-10">Select a document to inspect chunks</div>
          )}
        </div>
      </div>
    </div>
  );
}
