'use client';

import React from 'react';
import {
  Wrench,
  AlertTriangle,
  CheckCircle2,
  Clock,
  UserCheck,
  ShieldCheck,
  ArrowUpRight,
  Plus
} from 'lucide-react';

const MACHINES_FLEET = [
  {
    code: 'MACHINE-001',
    name: 'Gas Turbine Generator Unit-1',
    category: 'Gas Turbine',
    location: 'Building A - Sector 4',
    status: 'WARNING',
    temp: '94.5°C',
    vibration: '8.2 mm/s',
    lastService: '2025-11-10',
    recommendation: 'Schedule bearing race replacement and lubrication refresh within 72 hours.'
  },
  {
    code: 'TURBINE-002',
    name: 'High-Pressure Boiler Feed Pump',
    category: 'Feed Pump',
    location: 'Building B - Sector 1',
    status: 'NORMAL',
    temp: '72.1°C',
    vibration: '2.4 mm/s',
    lastService: '2025-12-01',
    recommendation: 'Maintain standard 180-day inspection schedule.'
  },
  {
    code: 'COMPRESSOR-003',
    name: 'Air Intake Centrifugal Compressor',
    category: 'Compressor',
    location: 'Building C - Outdoor Bay',
    status: 'CRITICAL',
    temp: '98.2°C',
    vibration: '11.5 mm/s',
    lastService: '2025-09-15',
    recommendation: 'Immediate shut-down inspection required. Excessive impeller vibration detected.'
  }
];

export default function MaintenanceFleetPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/40 border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center gap-2 text-amber-400 font-semibold text-xs tracking-wider uppercase">
            <Wrench className="w-4 h-4" />
            <span>Industrial Predictive Maintenance Subsystem</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Machine Asset Fleet Health Dashboard</h2>
          <p className="text-xs text-slate-400">
            Real-time equipment operational status, technician work order history, and AI predictive maintenance recommendations.
          </p>
        </div>
        <button className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-cyan-600 hover:from-amber-500 hover:to-cyan-500 text-white font-bold text-xs shadow-lg shadow-amber-500/20 flex items-center gap-2 transition">
          <Plus className="w-4 h-4" />
          <span>Register New Industrial Asset</span>
        </button>
      </div>

      {/* Fleet Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {MACHINES_FLEET.map((m, idx) => (
          <div key={idx} className="glass-panel p-5 rounded-2xl space-y-4 border-slate-800 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-white">{m.code}</span>
                <span
                  className={`text-[10px] font-bold px-2.5 py-0.5 rounded border ${
                    m.status === 'CRITICAL'
                      ? 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                      : m.status === 'WARNING'
                      ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                      : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                  }`}
                >
                  {m.status}
                </span>
              </div>

              <div>
                <h3 className="text-xs font-bold text-slate-200">{m.name}</h3>
                <p className="text-[11px] text-slate-400">{m.location}</p>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                  <div className="text-slate-500 text-[10px]">Temperature</div>
                  <div className="font-bold text-slate-200">{m.temp}</div>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                  <div className="text-slate-500 text-[10px]">Vibration</div>
                  <div className="font-bold text-slate-200">{m.vibration}</div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1 text-xs">
                <div className="text-[10px] text-cyan-400 font-bold flex items-center gap-1">
                  <Wrench className="w-3 h-3" />
                  <span>AI Maintenance Guidance:</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">{m.recommendation}</p>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3 text-slate-500" />
                Last Service: {m.lastService}
              </span>
              <span className="text-cyan-400 hover:underline cursor-pointer flex items-center gap-0.5">
                Work Orders <ArrowUpRight className="w-3 h-3" />
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
