'use client';

import React, { useState } from 'react';
import { ShieldAlert, Search, Filter, CheckCircle2, AlertTriangle, Lock, User, Clock, FileText } from 'lucide-react';

export default function AuditLogsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterAction, setFilterAction] = useState('ALL');

  const logs = [
    {
      id: 'log-101',
      timestamp: '2026-08-24 10:42:15',
      user: 'Rajesh Sharma (Senior Eng.)',
      action: 'QUERY_AI_WORKBENCH',
      agent: 'Maintenance Assistant Agent',
      model: 'Qwen2.5 14B',
      dataSource: 'Gas_Turbine_Manual.pdf',
      policyDecision: 'PASSED (ALLOWED)',
      securityEvent: 'LOW THREAT',
      result: 'Generated Assessment (Risk: MEDIUM)'
    },
    {
      id: 'log-102',
      timestamp: '2026-08-24 10:35:02',
      user: 'Rajesh Sharma (Senior Eng.)',
      action: 'RETRIEVAL_GUARD_CHECK',
      agent: 'Research Agent',
      model: 'BGE-M3 Dense Embeddings',
      dataSource: 'ChromaDB Local Index',
      policyDecision: 'PASSED (CONFIDENCE: 94%)',
      securityEvent: 'LOW THREAT',
      result: 'Verified 4 Citation Sources'
    },
    {
      id: 'log-103',
      timestamp: '2026-08-24 10:12:44',
      user: 'Anil Verma (Quality Inspector)',
      action: 'VISION_INSPECTION_FLAW_SCAN',
      agent: 'Inspection Analyst Agent',
      model: 'LLaVA 13B Vision',
      dataSource: 'turbine_bearing_inspection.jpg',
      policyDecision: 'PASSED (ALLOWED)',
      securityEvent: 'LOW THREAT',
      result: 'Flaw Detected: Surface Pitting (WARNING)'
    },
    {
      id: 'log-104',
      timestamp: '2026-08-24 09:55:18',
      user: 'System Administrator',
      action: 'POLICY_GATE_UPDATE',
      agent: 'Security Guard Agent',
      model: 'Policy Classifier',
      dataSource: 'RBAC Security Matrix',
      policyDecision: 'ENFORCED',
      securityEvent: 'AUDIT LOGGED',
      result: 'Updated Prompt Injection Guard'
    },
    {
      id: 'log-105',
      timestamp: '2026-08-24 09:20:10',
      user: 'Rajesh Sharma (Senior Eng.)',
      action: 'DOCUMENT_INGESTION',
      agent: 'Document Analyst Agent',
      model: 'PyMuPDF + BGE-M3',
      dataSource: 'Gas_Turbine_Manual.pdf',
      policyDecision: 'CLASSIFIED: CONFIDENTIAL',
      securityEvent: 'LOW THREAT',
      result: '38 Vector Chunks Ingested'
    }
  ];

  const filteredLogs = logs.filter((l) => {
    const matchesSearch =
      l.user.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.dataSource.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterAction === 'ALL' || l.action.includes(filterAction);
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl bg-slate-950 border border-slate-800 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-rose-400 font-semibold text-xs tracking-wider uppercase">
            <ShieldAlert className="w-4 h-4" />
            <span>Immutable Security Audit Log</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Enterprise Audit Trail Repository</h2>
          <p className="text-xs text-slate-400 max-w-2xl">
            Searchable and filterable on-premise log stream tracking user queries, AI model execution, data sources, policy decisions, and security events.
          </p>
        </div>

        <div className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-cyan-400">
          LOG STORAGE: LOCAL SQLITE IMMUTABLE
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-xl bg-slate-950 border border-slate-800">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search audit logs by user, action, or document..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-xs text-slate-400">Filter Action:</span>
          <select
            value={filterAction}
            onChange={(e) => setFilterAction(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none"
          >
            <option value="ALL">All Actions</option>
            <option value="QUERY_AI">AI Queries</option>
            <option value="RETRIEVAL_GUARD">Retrieval Guard</option>
            <option value="VISION_INSPECTION">Vision Inspection</option>
            <option value="DOCUMENT_INGESTION">Document Ingestion</option>
          </select>
        </div>
      </div>

      {/* Audit Log Stream Table */}
      <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white">System Audit Log Stream ({filteredLogs.length} Records)</h3>
          <span className="text-xs text-slate-400">Cryptographically Signed Log Hashes</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300 border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider">
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">User</th>
                <th className="py-3 px-4">Action</th>
                <th className="py-3 px-4">Agent / Model</th>
                <th className="py-3 px-4">Data Source</th>
                <th className="py-3 px-4">Policy Decision</th>
                <th className="py-3 px-4 text-right">Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-900/50 transition">
                  <td className="py-3 px-4 font-mono text-slate-400 text-[11px]">{log.timestamp}</td>
                  <td className="py-3 px-4 font-semibold text-white">{log.user}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                      {log.action}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    <div>{log.agent}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{log.model}</div>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-400">{log.dataSource}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      {log.policyDecision}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right text-slate-200 font-medium">{log.result}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
