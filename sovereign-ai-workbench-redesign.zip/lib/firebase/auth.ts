/**
 * Optional Firebase adapter.
 *
 * This deployment is designed to work without a cloud identity provider. The
 * login screen catches this explicit capability error and continues to the
 * existing FastAPI/local air-gapped authentication flow.
 */
const unavailable = () => {
  throw new Error('Firebase authentication is not configured for this sovereign deployment.');
};

export async function loginWithFirebase(_email: string, _password: string): Promise<any> {
  return unavailable();
}

export async function registerWithFirebase(_email: string, _password: string, _name: string, _department: string, _role: string): Promise<any> {
  return unavailable();
}
